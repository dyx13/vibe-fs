import assert from 'node:assert/strict'
import test from 'node:test'
import { writeFileSync } from 'node:fs'
import { withSuccessor, messageId } from '/Users/yuanxi/Workwork/vibe-fs/requirements/relay-context-projection/tests/support/cut.mjs'
import { sharedCapacitySnapshot } from '/Users/yuanxi/Workwork/vibe-fs/dist/OpenCode/Host/ModelRoutingSurface.js'

const stages = []
let currentRuntime
const mark = stage => {
  stages.push({ stage, at: new Date().toISOString() })
  process.stderr.write(`[diagnostic-only stage] ${stage}\n`)
}
process.once('beforeExit', () => {
  const receipt = {
    diagnosticOnly: true,
    variant: 'original-successor-body-without-added-session-deleted',
    stages,
    capacity: sharedCapacitySnapshot(),
    prompts: currentRuntime?.prompts,
    abortedIds: currentRuntime?.abortedIds,
  }
  writeFileSync('/private/tmp/vibe-fs-oct8-alias-release/r18-successor-no-delete-diagnostic.json', `${JSON.stringify(receipt, null, 2)}\n`, { flag: 'wx' })
  process.stderr.write(`[diagnostic-only final-stage] ${stages.at(-1)?.stage}\n`)
})

test('diagnostic-only original actual Continue successor body without added deletion', async () => {
  mark('before-withSuccessor')
  await withSuccessor(async ({ hooks, runtime, session, history, gate }) => {
    currentRuntime = runtime
    mark('original-body-entered')
    const output = { messages: [...structuredClone(history), gate] }
    mark('before-successor-transform')
    await hooks['experimental.chat.messages.transform']({ sessionID: session }, output)
    mark('after-successor-transform')
    for (const prior of history) {
      assert.ok(output.messages.some(message => messageId(message) === messageId(prior)), `lost physical message ${messageId(prior)}`)
    }
    assert.ok(output.messages.some(message => messageId(message) === messageId(gate)))
    assert.deepEqual(runtime.abortedIds, [session])
    assert.equal(runtime.prompts.filter(prompt => prompt.sessionID === session).length, 1)
    mark('original-body-assertions-complete')
  })
  mark('after-withSuccessor-and-dispose')
})

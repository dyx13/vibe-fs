import { sharedCapacitySnapshot } from '/Users/yuanxi/Workwork/vibe-fs/dist/OpenCode/Host/ModelRoutingSurface.js'

process.once('beforeExit', () => {
  process.stderr.write(`[diagnostic-only capacity at event-loop drain] ${JSON.stringify(sharedCapacitySnapshot())}\n`)
})

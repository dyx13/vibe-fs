# R17 第二次 Assessment 未启动：只读取证与正式红

输入是 dirty `ddb0c28cfbfa35762b2115f9609c85a296d68d1a`，generation 363，完整输入摘要 `2539cfc6606e9e152520df7a6ccf94df683bf8a1b79e908d6968f386febeee32`。原 E2E 前后输入相等；76,813.039792 ms，退出 1，未触发外层 timeout。原 TAP 为 34 pass、1 fail、0 skip、0 TODO。唯一失败是主 flow 等待 AssessmentCommitted gte 2，实际为 1；尚未执行 MCP custom。

## 事实链

本次原始 scratch：`/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/oc-e2e-ESpu2v`。

原始 journal：`workspace/.git/wanxiang/events/373a61bb73924ea9934fe540ae8ac2b5.ndjson`，共 333 行。主 Manager 是 `ses_ee4c4fb81ffeZckZDy1ydZtH6B`，Road 同名；Root 为 `msg_11b3b04a7001sOyhD6ZIU1AlSo`，logical run 为 `c1ad4214aad391b42bebe9840ee90faeb9e24ec7cab389b2d6649878e0872062`。主 Orchestrator 为 `ses_ee4c4fd82ffe58fJAgKHdk0ahP`，真实 job `n4mr0c`。

| journal 行 | UTC 时间 | 实际事实 |
| --- | --- | --- |
| 234 | 11:16:55.913 | 主 Road 第一次 AssessmentCommitted，completeness Revise，其余 Perfect |
| 270、279 | 11:16:56.240、56.358 | 主场景两次已声明 provider 400；不是本次新失败 |
| 322 | 11:16:57.092 | Continue retirement，cut provider `msg_11b3b0bed001lG7MVqZ2GKWWZx` / tool `call_41` |
| 323 | 11:16:57.173 | successor IncumbencyOpened |
| 324 | 11:16:57.177 | 退休对应 ManagerGuard PromptClaimed，原 Root/logical run |
| 325 | 11:16:57.184 | 新 physical user `msg_11b3b0cdc001NuQNeuQaZ23sDD` 已接纳 |
| 326 | 11:16:57.188 | 新 physical user ChatExecutionAccepted |
| 327 | 11:16:57.204 | 旧 physical guard `msg_11b3b0a9a001PaDq5Yu7RmZK0u` Cancelled |
| 328 | 11:16:57.209 | 新 prompt Submitted |
| 329 | 11:16:57.281 | 再次 IncumbencyOpened，ID 与 323 完全相同 |

两个 opening 均为 `incumbency:21c6422e18ce2d14d0b02f80140dde0d569b17de8a0318e9093b2b8f154c7f2a`，snapshot 均为 `fd9f2b4ecac93a98905005fccaaba7a222d7d3f8667706bcc81bbe2d62128e6b`。这是重复持久事实，不是第三个任期。

SQLite 以 `mode=ro` 读取。新 user 创建于 11:16:57.180，此后没有它的 assistant。旧 attempt 的下一 assistant placeholder `msg_11b3b0c890016z0EyztnVBS772` 于 57.097 创建，parent 仍是旧 guard，于 57.191 以 MessageAbortedError 结束。Host log 259 行在 57.191 记录同一主 Manager 的 `message=cancel`。之后没有该 Manager 的新 loop/process/stream。

这排除了 waitFact 绑定到错误 Road 的解释，也排除了“第二条 Assessment 已产生但 observer 漏记”的解释。它证明新的持久接纳已经发生，但 provider 执行没有开始。原 HTTP 请求数组并未持久化，不能补称完整 wire 证明。

## 生产调用链和有限因果结论

`requirements/relay-retirement/WHAT.md` [008] 要求释放 exact provider-step admission、等待旧 attempt 物理中断完成，然后派发 Continue 后继；明确禁止后继派发后再补旧任 session abort。

旧 transform 路径：`OpenCode/Plugin/PluginTransforms.fs` 615–646 → `Mission/Manager/Workflow.fs` continueAfterRetiredAttempt。它在 await stop 前读取 loop context，保存 needsOpening；stop callback 先 suppress/release exact physical execution，再 await `ISessionHostPort.InterruptAttempt`。实际 adapter 位于 `OpenCode/Host/Sessions.fs` interruptManagedAttempt，底层由 OpenCodePort 发送真实 session abort。

独立 Change 路径：commission 激活后，`Change/Runtime.fs` startPublication 立即运行 `Change/Program.fs` runManagerLoop。Continue retirement 唤醒真实 journal revision 等待，程序依次进入 ContinueLoop 和下一次 AwaitLoopSignal。`Change/Host/Host.fs` activateNextIfAbsent 先 append successor opening；active incumbent 使 awaitLoopSignal 进入 awaitDispatchedWait（195 行），其 ContinueManagerLoop 由 `OpenCode/Plugin/PluginHooks.fs` 217 行绑定到 ManagerWorkflow.maybeDeliverLoop。后者不等待旧 attempt stop，直接 deliverLoopContext/send。

因此，同一正常 Change 流程可以在旧 transform await abort 期间发出后继。旧 transform 随后恢复时还使用先前 needsOpening=true 的 context，再提交相同 deterministic successor opening。此源路径与 323→328→329 的真实顺序吻合。Journal 并未保存调用方名称，不能单凭它给每次 append 唯一署名；下述正式红独立证明真实 Change 路径确实绕过中断边界。无需假设存在第二次旧 abort，一个晚到的 abort 已足以解释新 prompt 未开始执行。

## 正式红

仅新增 `requirements/relay-retirement/tests/support/change-interrupt.mjs` 与 008 中的新正式用例；未修改生产、原断言、预算或原 TODO。夹具使用真实插件、真实 journal、真实 Git worktree、真实 commission 和实际 SDK session adapter。

受控顺序：首 Manager prompt 先经真实 chat.message 完成 Root 接纳，再挂起 SDK 返回，故 Change.Runtime 尚未 startPublication。夹具真实执行 review / suicide，确认退休体不 abort、不发送，然后放行初次 activation，让实际 Change workflow 运行。使用 SDK `promptAsync` 与 `abort` 两个真实调用的 Promise.race 判定先后，不依赖 sleep 或微任务次数。

执行命令：

```sh
source /private/tmp/vibe-fs-release-env-oct8-7eQsBo/env.sh
export WXS_VERIFICATION_NUGET_PROJECT_TREE_ID=$(git rev-parse 'HEAD^{tree}')
node --test requirements/relay-retirement/tests/008.test.mjs > /private/tmp/vibe-fs-oct8-alias-release/r17-assessment-readonly/relay008-change-interrupt-red.log 2>&1
```

工具：Node `/private/tmp/node-v22.23.3-darwin-arm64/bin/node` v22.23.3，npm 11.12.1。直接 requirement 测试使用 generation 363，不执行构建新鲜度门禁；不能称新 JS 测试已纳入该旧 manifest。首轮正式红 3,446.278833 ms，exit 1，4 pass、1 fail、0 cancelled、0 skipped、1 TODO。唯一失败是实际 `send`，预期 `interrupt`。这是在追加反向及失败两 case 之前的 6-case 输入；后续 case 尚未执行，不能授其红/绿计数。

首红后补充的正式边界：旧 transform 先进入 abort barrier，再放行初始 activation 并等待真实 public commission 结算（Runtime 已启动 Change publication），最后放行 abort，检查 1 abort / 1 send / 2 条 opening 事实；另以 SDK abort 的原始受控异常证明 0 send、真实 Change join 失败结算、迟到 transform 不重试失败 stop。反向 case 不要求在 stop 完成前已经 append successor，避免约束合理的 stop→open→send 修复。原 installed Host 额外覆盖 TODO 原样保留。

另补两条双实例正式 case：从真实 Manager SDK 请求的 directory header 取得真实 linked worktree，实核它与 root workspace 的 common-dir 相同，再用同一实际 SDK client 在 worktree 目录启动第二次 `plugin.server`。Manager chat.message/review/suicide/transform 由 worktree hooks 承接，Change commission/join 由 root hooks 承接。change-first / transform-first 各要求一次物理 stop、一次 successor send、初始及 successor 各一条 opening。Manager session 每次由实际 CreateChildSession mint，避免持久保留的 stop receipt 在测试间串用。

原 Accepted 正式 fixture 首红时未提供 retirement-run 的 Host assistant parent；新 resolver 不允许无证据回退，因此补上真实 Host message、parent=user-root、suicide-call。008 内前两条静态 review-manager fixture 在 owner 尚存活的 finally 中发送真实 session.deleted，仅清自身 session。没有改共用 withReview，也没有把 Dispose 当成清除跨实例状态的依据。这些新夹具变动均待新 build 后验证；旧 generation 363 对已变生产源不新鲜，未拿它授新增测试正式红。

## 第一版修复验证的失败与夹具前提修正

第一版修复构建先因显式 Task 返回类型、模块 open 与同名 PhysicalUserMessageId 类型发生编译错误，未发布新 generation。Root 修正后构建发布 generation 364。首轮完整 008 日志是 `/private/tmp/vibe-fs-oct8-alias-release/r18-stop-owner-first-green.log`，其文件名不是验收结论：实际 exit 1，1 pass、0 assertion fail、8 cancelled、0 skipped、1 TODO，1,693.460833 ms。第二个 withSuccessor case 的 Promise 未结算，event loop 已排空；其后的五条新回归未执行，不能授其通过。

只读调用链中 SDK chat.message 不调用 ManagerWorkflow 或 exact-cut stop owner；主要进入 ChatAdmissionTransaction / 每 session admission turn / 容量等待。未找到它直接重入同 cut 的证据。夹具同时存在真实的身份前提问题：第一个 case 发出 session.deleted，后一个 withReview 又复用了同一 `review-manager` / `user-root`。真实 Host 不会把已删除的 SessionId 分配给另一会话，进程共享 provider-step suppression / stop ownership 也不得被测试的 Dispose 清空来伪造复用。

经 Root 授权，对 withReview 只增加 `node:crypto` randomUUID import，将 session 改为每次 `review-manager-${randomUUID()}`。`rg -n 'review-manager' requirements` 全树仅命中该 helper；所有 consumer 都接收它返回的 session。这个改动建立独立身份前提，不改变交错调度，全部竞态仍由受控 barrier 固定。008 两处精确 owned session.deleted 保留。此时尚未用新输入构建/验证，因此 generation 364 的取消究竟是否全由身份复用导致仍待反证，不能直接写成已修复。

## 追加反证：独立身份并非取消的充分原因

generation 365 的完整 008 仍为 1 pass / 8 cancelled / 1 TODO。定点诊断的 event-loop drain 显示 Blogger child 持有 credit 2，但这不构成主 transform 死锁的证据。

经 Root 授权，TMP 诊断只复用 withSuccessor 原主体，保留全部历史、单次 abort 和单次 Manager prompt 断言，移除本轮新增的 session.deleted finally。`r18-successor-no-delete-diagnostic.log` 实际 exit 0、1 pass、0 fail、0 cancelled、0 skip、0 TODO，1,352.452375 ms。阶段记录依次到达 successor transform 返回、原主体断言完成、withSuccessor 及正常 dispose 返回；正常 dispose 已中断本轮 Blogger，最终 custodies / executions 为空。其 JSON 收据是 `r18-successor-no-delete-diagnostic.json`。

因此撤回 008 前两条本轮新增的 session.deleted try/finally，保留独立 UUID 和正常 withExecutablePlugin.dispose。物理删除事件在 Host stub 尚保留 live child 时并非合法清理替身；不通过全局清空 stop owner 伪造测试隔离。该定点诊断仅定位夹具前提，不是正式 requirement 验收。

## 追加正式红：fresh HumanRoot 后迟到旧 cut

在现有第三条 Accepted→新 HumanRoot case 中，真实 chat.message 已接纳新输入、fresh transform 尚未执行时，插入旧 user / review / retirement 物理请求。新增断言要求旧 messages 被清空、0 abort、prompt 数量不增，以及新 activeLogicalRun 完整相等。

构建 generation 366 成功；定点正式命令 `node --test --test-name-pattern='physical prompt after Accepted suicide invalidates certificate' requirements/relay-retirement/tests/008.test.mjs` 实际 exit 1、0 pass、1 fail、0 cancelled、0 skip、0 TODO，1,576.741292 ms。失败为 `EMR-010: managed provider step for physical user message root-ses-accepted-human-successor has no committed model-routing lease`，出现在 BeginPhysicalProviderAttempt，尚未到新增 0 abort 断言。不能将此红表述为已观测到错误 session abort；它证明旧请求在 RelayProjection 前已因旧 lease 前提拒绝。日志为 `r18-fresh-human-late-cut-red.log`，构建日志为 `r18-fresh-human-late-cut-red-build.log`。

## generation 367 的后继 transform 取证边界

加入第二次迟到旧请求后，以 generation 367 定点执行同一个原 case，`r18-fresh-road-advance-red.log` 实际 exit 0、1 pass、0 fail、0 cancelled、0 skip、0 TODO，1,419.419375 ms；文件名中的 red 不代表结果。该次两窗口共用一个 exact cut，首窗口会建立成功 no-op stop cache，故第二窗口不能独立证明 cold guard。

只读核实：普通 HumanRoot 首 transform 通过 `ensureManagerRoadOpened` 为 Accepted Road 开 successor，沿用原 Road AuthorityRevision；Fold.commitAuthorityAdvance 的实际生产事件入口是 Change.Host.continueManagerJobCore 的 AuthorityRevisionAdvanced，未由这里的普通 transform 触发。因此后继 transform 不得被称为 Road revision 已推进。Root 决定仅拆 admission / successor-transform 两个独立 cold fixture，暂不扩展 Change authority 更新需求。该后续变动与执行结果待另记，不能借本次绿覆盖修订后的输入。

## generation 367 / 368 的正式结果

Root 在 generation 367 执行完整 008，日志 `r18-full008-first-proof.log` 实际 exit 0、9 pass、0 fail、0 cancelled、0 skip、1 原 TODO，6,805.801416 ms。

随后第三个正式 case 拆为两个真正独立的 withExecutablePlugin fixture：`admission` 在新 HumanRoot 接纳后投递一次旧历史；`successor-transform` 则在新请求 transform 完成后才首次投递旧历史。两次使用不同 session ID，各自的 stop owner 都未由另一窗口预热；没有发送 session.deleted，也未清空全局 cache。每个窗口均保留 empty / 0 abort / prompt 不增 / exact freshOwner / Road snapshot 不变断言；每次均继续执行原 fresh transform 和 fork 权限正例。这里没有 AuthorityRevisionAdvanced 前提，名称不再误称 road-advance。

刷新构建 generation 368 成功；定点正式命令与原名称相同，日志 `r18-fresh-successor-cold-proof.log` 实际 exit 0、1 pass、0 fail、0 cancelled、0 skip、0 TODO，2,264.682041 ms。这条 test 包含上述两个独立 fixture。完整 008 的 9 pass / 1 TODO 收据属于 generation 367；最新输入仅重验变更的第三条，不能将旧全文件收据改写成 generation 368 的完整执行。普通 current sequence 和 cognitive-environment 无 committed lease 的正式负控未改。

## 修复建议与未证范围

两入口共享 exact retirement cut 所拥有的一次 physical-stop Task；Change 可以先发起 stop，迟到旧 transform 复用已结算成功或失败，绝不再次 abort。stop 成功后重新读取 durable context，不使用 await 前的 needsOpening。须保持原 Root、logical run、完成订阅、manager-loop gate、Continue 自动派发及 Accepted 仅显式失效重开规则。

这项正式红只证明实际插件语义路径和受控 SDK adapter 边界；尚不能代替修复后的 installed Host E2E、MCP custom、全项目 release 或原吞吐问题验收。原 gte 2、两个 400、500 重试、epoch 与 loop 数量不得放宽。

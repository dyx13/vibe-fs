# R18 readonly audit: opening append and authority replacement

Status: source-level asynchronous window confirmed; no executable formal reproduction obtained in this audit. No new production API or behavior change is justified by this receipt alone.

## Confirmed call path

1. `PluginTransforms.atRetiredAttemptBoundary` calls the shared exact `(SessionId, ProviderRunIdentity, ToolCallId)` owner. The stop task is installed before work starts; success and failure remain registered until session deletion. Follow-up callbacks are serialized, and a previous follow-up failure cannot retry the stop.
2. The boundary rechecks `RelayNarrativeTransform.retirementOwnsAuthority` before interruption, after resolving the exact old run's physical parent, and before entering the follow-up callback. Fresh authority therefore suppresses the old request without rebinding that cut to a current physical request.
3. `ManagerWorkflow.afterRetiredAttempt` rereads the loop context after stopping, checking the captured retirement ID and cut instead of retaining the old `needsOpening` value.
4. `deliverLoopContext` awaits `commitOpeningTransaction`, which awaits `AgentJournal.appendAgent`. `AgentJournal.AppendAndPublish` awaits `IJournalWriter.Append`. `EventStoreJournalWriter.RunAcceptedAppend` awaits the prior writer task. The compiled Fable code contains the same Promise `Bind` chain, even when eventual disk writes are synchronous.
5. After that await, `deliverLoopPrompt` uses `HostSessionNudge.trySendGateContinuation`, which selects the then-current active profile. Thus the boundary's earlier authority observation is not itself the profile used by the eventual send.

The last item identifies a candidate authority-replacement window, not proof that a legal new HumanRoot can enter that exact window in a real scenario. Such proof remains required before changing production behavior.

## Existing precise send capability

`PromptDispatcher.Runtime.SendGateNudge` already accepts `PromptAuthority.AuthorityExecutionProfile`. Its existing continuation path checks `RequireActiveProfile` both before persisting a claim and immediately before physical `SendPrompt`. If the candidate window is proved, the narrow approach is to preserve the expected profile across opening and pass that same profile into this existing path. The private HostSessionNudge profile wrapper also has an `AlreadyAdmitted` shortcut; any exposed expected-profile entry would need to reject a mismatched active profile before reporting that shortcut as success.

No such entry was added in this audit. A broad retirement/road authority-revision equality condition was not adopted: a legitimate same-Root authority update can change the road revision.

## Formal proof prerequisite

A repository-wide read found no public Manager or Journal `beforeAppend` barrier. Existing `afterAppendJournal` wrappers are scoped to PromptJournal operations, not the Manager opening transaction. Monkeypatching opaque `JournalHandle.journal.writer.Append` from JS would cross the registered semantic-surface boundary and is not a suitable hurried formal regression.

A future controlled test must hold the real opening transaction at an admitted append boundary, accept a legal new Root through the production authority boundary, release the append, then assert no old gate reaches that new Root and its profile/accepted execution remain intact. It must establish the legal Root replacement prerequisite and use the real writer/fold; a synthetic projection change is insufficient.

## Other reviewed R18 properties

- Same-cut follow-up serialization and persistent stop failure are present in SharedState; per-plugin Dispose does not clear the cross-instance owner.
- Session deletion drops the corresponding shared entries; compiled structural identity comparison is present.
- Cold durable manager-loop acceptance skips a second session abort before attempting old-run parent resolution.
- Change no longer opens a successor itself. It calls the Manager owner and then confirms the deterministic `IncumbencyOpening.nextId` is active or already durably retired, so a fast completed successor remains a valid completion witness.
- Root and linked-worktree callbacks use the same SharedState owner. The formal linked-worktree tests, not this read-only audit, own executable evidence.

## Scope of this receipt

No tests, builds, source changes, cleanup, commits, or pushes were performed for this audit. Parent-reported formal counts are deliberately not restated as independently observed verification here. The opening-window case remains an explicitly unproved boundary rather than a new closed TODO or complete Host acceptance claim.

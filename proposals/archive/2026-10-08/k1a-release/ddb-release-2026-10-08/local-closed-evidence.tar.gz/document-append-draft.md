以下仅为候选 `ddb` 的文档追加草案；尚未写入仓库。归档链接需由 root 在新的独立归档目录建立后替换。不能向已封口的 r8-r11、R10 或 R12 目录追加这些日志，也不能把本次候选收据借给后继代码或最终纯文档提交。

## 建议追加到 proposals/K1A与全项目release验收-2026-10-08.md

### 候选 ddb 的完整本机执行与同提交 CI（未通过）

本次候选输入为 `ddb0c28cfbfa35762b2115f9609c85a296d68d1a`，tree `06cc8ac28bd604e867cbb0244bf918b8ee4ea4ad`，4664项 verification 输入摘要 `fb36b4e2f95ad89f1534c15f077e497a82b6470a0becc782785b57e03adc3633`。统一入口前后 commit、tree、digest、输入数及工作区 status/diff 一致且干净；三个独立补跑各记录相同 commit/digest 与 inputsEqual=true，未单独捕获其前后 Git status。选定 Node22.23.3/npm11.12.1/SDK10.0.302、Fable5.13.0/Fantomas6.3.0；并发2、UNIT_VERDICT_SILENCE_MS=30000；没有筛选正式统一unit文件，没有扩充原预算。统一wrapper未另设总预算。

| 阶段 | 输入 | 命令/环境 | 耗时 | exit | 文件完成/计划、active/queued | pass/fail/skip/TODO | 资源、原件 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 统一format | ddb | npm run format:check | 0.4s | 0 | unknown | unknown | Wireit Ran0/skipped1，缓存命中；不是本机重新扫描；stages/format-check.log |
| 统一check | ddb | npm run check | 0.3s | 0 | unknown | unknown | 同为Ran0/skipped1；stages/check.log |
| 统一干净Fable | ddb | node scripts/build.mjs --clean | 43.0s | 0 | unknown | unknown | gen342、1815sources/891artifacts、175surfaces/835modules；build.log及前后manifest |
| 统一unit | ddb | node requirements/verification-system/tests/run.mjs；2/30000ms | 300.8s | 1 | 556/824，558已准入、2active、266queued | unknown/unknown/unknown/unknown | 原300000ms backstop；inner33904残留75489回收后accepted=false/146.904ms；原日志不可覆盖 |
| 统一integration/E2E/package | ddb | 原verificationSteps后续阶段 | not-run | not-run | not-run | not-run | 非零后停止；独立补跑不能改成统一通过 |
| 独立全integration | ddb、原摘要 | WXS_RELEASE=1 node requirements/verification-system/tests/integration/run.mjs；外1200s/父内300s | 314.468s | 1 | 父43/44、1active016、0queued；三个group均有结果 | unknown/unknown/unknown/unknown | 父inner76127 accepted=true/16.597ms；monitor76097 ESRCH；inputsEqual=true |
| integration/distribution | 同上 | 原distribution package子入口 | 0.2s | 1 | 1/1 | 3/0/0/1 | 只因pending；inner85833 accepted=true/16.291ms |
| integration/harness | 同上 | 原harness子入口 | 12.4s | 0 | 文件数unknown | 292/0/unknown/unknown | 父只保成功汇总，子清理细节unknown；不能补造skip/TODO0 |
| 独立release Long Stroke | ddb、原摘要 | WXS_TIER_RELEASE=1/WXS_RELEASE=0 node requirements/verification-system/tests/014.test.mjs；原1500s | 14.879s | 1 | 计划1文件，完成数unknown | unknown/unknown/unknown/unknown | 前13个ok可见；actual fatal后无TAP总汇；monitor86518 ESRCH、owned completion failure=null；Host/scratch单独清理unknown |
| 独立真实package | ddb、原摘要 | WXS_RELEASE=0 node scripts/verify-package.mjs；原600s | 5.261s | 0 | 非TAP，文件计数不适用 | unknown/unknown/unknown/unknown | gen342；真实pack/解包/隔离消费者；monitor87048 ESRCH；scratch文件清理unknown |
| exact官方CI | ddb、GitHub独立digest前缀c487ba1f17633305 | run37756691987，原verify:release；2/30000ms | 总313.9s/unit248.9s | 1 pending | unit824/824、active0/queued0 | 4938/0/128/388 | inner2831 accepted=true/7.763ms；CI后续三阶段not-run；不是后继final SHA收据 |

统一入口从09:27:08.252Z开始，owned工具wall347.942s、verify自身报告347.7s、wrapper完整349.999s。入口工具PID33425、monitor33424；monitor最终ESRCH且owned completion failure=null，只证明该wrapper边界完成，不能覆盖unit记录的accepted=false。unit在原backstop时仍活跃 `prefix-stability/012` 与 `process-execution/001`；前者最后verdict是保留新合法请求的Failed settlement通过，后者尚无verdict。完整全局summary缺失，不能从已完成叶或故意红负控统计全套四计数。终局精确33867/33904/75489/75877均ESRCH；不由这四个PID授予未知后代或文件清理。

独立integration实际开始时间为09:50:32.989Z，314.468s内没有触发1200s wrapper预算，触发的是父suite原300000ms backstop；父43/44，016唯一active。其最后verdict为readonly mount protects original role paths测试通过，不能据此把后续尚未完成body记通过。父suite四计数unknown，distribution的1TODO仍使该group失败；harness292pass/0fail仅授该子group。父入口最终2个失败group、1个通过group，不是测试叶计数。

系统Maintenance Sleep发生17:33:17..17:50:32+0800，共1035s；在unit终局之后、独立integration实际启动之前。它属于启动前环境延迟，不在integration原阶段预算内，不能解释本次unit或integration的300s截断。17:52:47另给本轮owned caffeinate增加PreventSystemSleep，属于原失败后的环境变化；不能追认修复此前结果。原pmset证据与时间范围保留。

Long Stroke实际失败是 `no-declared-turn (lane=manager|strength-recovery-owner kind=chat step=1)`；Host尾部同时有 `strength-fuse-tripped`/`skipped-recovery-fuse`。没有末尾TAP总汇，不能填13pass/1fail，也不能将实际fatal当作正式用例已产出的fail计数。R13仍施工中，须追查第一个fuse原因并补正式回归；不放宽严格matcher、补虚构cursor或删原两Bound/请求数量断言。输出前13项ok是局部事实，完整Host验收仍失败。

package原CLI未传skipConsumer，完成npm pack、完整archive closure验证、严格解包、active registrations与隔离npm ci/consumer，并在结尾重新验证gen342及输入新鲜度。tarball `wanxiangshu-0.9.0.tgz` rawSHA256为 `660de068c3463163889f8159458ca1a4a6609d3fe99045ee5d19f3eef7154055`，压缩字节2532823、2073成员、成员总字节12488691；审计重新核对原tgz rawSHA及tar成员数一致。verifyPackage的finally会捕获scratch rmSync错误，且未输出独占目录身份/删除收据，所以scratch文件清理unknown。package成功不代表全项目release。

官方[CI37756691987](https://github.com/dyx13/vibe-fs/actions/runs/37756691987)精确head/tree/checkout/artifact head一致，artifact11540502395下载rawSHA256 `c4c71a1090ee4f838fee3243501a2a47f36ea085d166adadac96a3bf37874be3` 与GitHub公布digest一致。CI实际format7.5s/check4.4s均跑1项无缓存skip，cleanbuild51.9s；unit248.9s完整824排空、0普通断言失败，但128skip/388TODO使pending policy返回1。该次CI完整排空是一次观察，不能因此宣布本机截断或稳定吞吐已闭合。机器/工具环境与全输入digest不同；不能拼接本机和CI四计数，也不能借给后继提交。

此候选全项目结论仍失败：本机unit与integration原预算截断，distribution待证，真实release E2E fatal；官方CI为pending policy失败。R13首cause、吞吐变化因果及上述unknown边界尚未闭合。任何源码变化后必须重新构建、冻结、相应复验并核对新提交CI。

本轮新TMP封口目录为 `/private/tmp/vibe-fs-oct8-final-release-audit-ddb/`，包含28份闭合原件副本、candidate-local-matrix.json、closure-inventory.json、SHA256SUMS及本草案；原始运行目录 `/private/tmp/vibe-fs-oct8-final-release/` 保持原样。CI独立原件仍在 `/private/tmp/vibe-fs-oct8-alias-release/ci-ddb0c28cfbfa-37756691987/`。归档时使用新目录，保留本机截断和CI pending两种失败，不向旧已封口目录加文件。

## 建议同步总计划的状态短句

K1-A代码及已有正式回归保持有限闭环；候选ddb本机完整release已执行但未通过，不能授GAP-160或全Host验收。unit556/824及integration父43/44原300s截断、四计数unknown；distribution3pass/0fail/0skip/1TODO，harness292pass/0fail但skip/TODOunknown；实际Long Stroke fatal无完整TAP汇总，R13继续调查；真实package成功，scratch文件清理unknown。exact ddb CI完整824排空4938pass/0fail/128skip/388TODO，仅pending退出1，后续三阶段not-run。1035s系统睡眠在独立integration实际启动之前，不算阶段预算内截断原因。状态保持“全项目验收失败/施工中”，新代码需新冻结和新SHA CI。

## 建议同步测试说明的边界短句

候选ddb完整入口和独立补跑按原tier/并发/预算执行，未将分批或跨机器结果拼作一次全量通过。没有权威总汇时用unknown：本机unit、integration父suite、fatal Long Stroke全套四计数均unknown；harness仅能确认292pass/0fail，skip/TODOunknown；package为非TAP，四计数unknown。Wireit cache skip与test skip分开记录，清理明确区分unit reclaimed accepted=false、独立monitor ESRCH、实际inner group接受及无收据的文件清理unknown。

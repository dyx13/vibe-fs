import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { finished } from 'node:stream/promises'
import { collectVerificationInputs, computeDigest } from '/Users/yuanxi/Workwork/vibe-fs/scripts/lib/build-state.mjs'
import { spawnOwnedVerificationTool } from '/Users/yuanxi/Workwork/vibe-fs/scripts/lib/verification-owned-tool.mjs'

const root = '/Users/yuanxi/Workwork/vibe-fs'
const directory = '/private/tmp/vibe-fs-oct8-final-release'
const wrapperStarted = performance.now()
const logPath = path.join(directory, 'release-console.log')
const receiptPath = path.join(directory, 'unified-release.json')
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const git = args => execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()
const input = () => {
  const inputs = collectVerificationInputs(root)
  return { commit: git(['rev-parse', 'HEAD']), tree: git(['rev-parse', 'HEAD^{tree}']),
    status: git(['status', '--porcelain=v1']), diff: git(['diff', '--binary']),
    digest: computeDigest(inputs), inputCount: inputs.length }
}
const describe = (error, seen = new Set()) => {
  if (error === null || error === undefined) return null
  if (typeof error !== 'object') return { value: String(error) }
  if (seen.has(error)) return { circularReference: true }
  seen.add(error)
  return { name: error.name, message: error.message, stack: error.stack,
    code: error.code, errno: error.errno, syscall: error.syscall, path: error.path,
    cause: error.cause === undefined ? undefined : describe(error.cause, seen),
    errors: Array.isArray(error.errors) ? error.errors.map(value => describe(value, seen)) : undefined }
}
const manifest = label => {
  const sourcePath = path.join(root, '.fable-build/build-manifest.json')
  if (!fs.existsSync(sourcePath)) return { exists: false, sourcePath, capturePath: null, sha256: null }
  const bytes = fs.readFileSync(sourcePath)
  const capturePath = path.join(directory, `unified-build-manifest-${label}.json`)
  fs.writeFileSync(capturePath, bytes, { flag: 'wx' })
  let parsed
  let parseFailure
  try { parsed = JSON.parse(bytes) } catch (error) { parseFailure = describe(error) }
  return { exists: true, sourcePath, capturePath, bytes: bytes.length, sha256: hash(bytes),
    generation: parsed?.generation, parseFailure }
}

const frozen = JSON.parse(fs.readFileSync(path.join(directory, 'frozen-input.json'), 'utf8'))
const before = input()
if (before.commit !== frozen.commit || before.tree !== frozen.tree || before.digest !== frozen.digest ||
    before.status || before.diff || before.inputCount !== frozen.inputCount) {
  throw new Error('Unified release requires the exact clean frozen final commit/tree/input inventory')
}
if (process.env.WXS_VERIFICATION_NUGET_PROJECT_TREE_ID !== before.tree) {
  throw new Error('Selected project tree must equal the frozen final tree')
}
for (const name of ['TESTS_MJS_FILES', 'NODE_TEST_VERBOSE', 'NODE_TEST_CONTEXT', 'WXS_TIER_INTEGRATION', 'WXS_TIER_RELEASE', 'WXS_RELEASE']) {
  if (process.env[name] !== undefined) throw new Error(`Unified release requires ${name} to be unset before the original entry`)
}
for (const file of [logPath, receiptPath, path.join(directory, 'unified-build-manifest-before.json'), path.join(directory, 'unified-build-manifest-after.json')]) {
  if (fs.existsSync(file)) throw new Error(`Refusing to overwrite historical evidence: ${file}`)
}
const manifestBefore = manifest('before')
const env = { ...process.env, NODE_TEST_CONCURRENCY: '2', UNIT_VERDICT_SILENCE_MS: '30000' }
const log = fs.createWriteStream(logPath, { fd: fs.openSync(logPath, 'wx'), autoClose: true })
let loggingFailure
let owned
log.on('error', error => { loggingFailure ??= error; owned?.stop() })
const startedAt = new Date().toISOString()
const start = performance.now()
owned = spawnOwnedVerificationTool('npm', ['run', 'verify:release'], { cwd: root, env })
for (const stream of [owned.child.stdout, owned.child.stderr]) stream.on('data', chunk => {
  if (!log.destroyed) log.write(chunk)
})
const [started, result] = await Promise.all([owned.started, owned.completed])
const durationMs = performance.now() - start
log.end()
await finished(log).catch(error => { loggingFailure ??= error })
let monitorObservation
try { process.kill(owned.child.pid, 0); monitorObservation = 'still-running' }
catch (error) { monitorObservation = error.code ?? String(error) }
let after
let afterInputFailure
try { after = input() } catch (error) { afterInputFailure = describe(error) }
let manifestAfter
let afterManifestFailure
try { manifestAfter = manifest('after') } catch (error) { afterManifestFailure = describe(error) }
let actualStageLogDirectory
try { actualStageLogDirectory = fs.realpathSync(path.join(root, '.fable-build/verify-logs/latest')) }
catch { actualStageLogDirectory = 'unknown' }
const inputsEqual = after !== undefined && before.commit === after.commit && before.tree === after.tree &&
  before.digest === after.digest && before.inputCount === after.inputCount && before.status === after.status && before.diff === after.diff
const accepted = result.exitCode === 0 && result.signal === null && result.failure === null &&
  started.failure === null && monitorObservation === 'ESRCH' && inputsEqual &&
  !loggingFailure && !afterInputFailure && !afterManifestFailure
const receipt = { kind: 'Exact frozen-input unified release, owned-tool wrapper; no extra overall budget',
  command: ['npm', 'run', 'verify:release'], cwd: root, inputCommit: frozen.commit, inputTree: frozen.tree,
  frozenReceipt: path.join(directory, 'frozen-input.json'), before, after, inputsEqual,
  startedAt, durationMs, wallMs: durationMs, wrapperDurationMs: performance.now() - wrapperStarted,
  exitCode: result.exitCode, signal: result.signal, failure: describe(result.failure),
  started: { pid: started.pid, failure: describe(started.failure) },
  monitorPid: owned.child.pid, monitorObservation, cleanupFailure: describe(result.failure),
  cleanupScope: 'Owned monitor/group completion and exact monitor PID observation; no global process scan or filesystem disposal claim',
  environment: { NODE_TEST_CONCURRENCY: env.NODE_TEST_CONCURRENCY, UNIT_VERDICT_SILENCE_MS: env.UNIT_VERDICT_SILENCE_MS,
    WXS_VERIFICATION_NUGET_PROJECT_TREE_ID: env.WXS_VERIFICATION_NUGET_PROJECT_TREE_ID,
    TESTS_MJS_FILES: 'unset', NODE_TEST_CONTEXT: 'unset', WXS_TIER_INTEGRATION: 'unset', WXS_TIER_RELEASE: 'unset', WXS_RELEASE: 'unset' },
  budgetAuthority: 'scripts/verify.mjs verificationSteps and unchanged per-stage/internal budgets',
  buildManifestBefore: manifestBefore, buildManifestAfter: manifestAfter,
  afterInputFailure, afterManifestFailure, loggingFailure: describe(loggingFailure),
  log: logPath, logSha256: hash(fs.readFileSync(logPath)), actualStageLogDirectory, accepted }
fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' })
process.stdout.write(JSON.stringify(receipt, null, 2) + '\n')
process.exitCode = accepted ? 0 : Number.isInteger(result.exitCode) && result.exitCode !== 0 ? result.exitCode : 1

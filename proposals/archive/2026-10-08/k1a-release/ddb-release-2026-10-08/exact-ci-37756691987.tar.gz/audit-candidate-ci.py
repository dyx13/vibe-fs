from pathlib import Path
import json,re,collections,hashlib,datetime
p=Path('/private/tmp/vibe-fs-oct8-alias-release/ci-ddb0c28cfbfa-37756691987')
sha='ddb0c28cfbfa35762b2115f9609c85a296d68d1a';tree='06cc8ac28bd604e867cbb0244bf918b8ee4ea4ad'
r=json.loads((p/'run.json').read_text());j=json.loads((p/'jobs.json').read_text());a=json.loads((p/'artifacts.json').read_text())['artifacts'][0];c=json.loads((p/'source-commit.json').read_text())
assert r['head_sha']==sha and c['tree']['sha']==tree and a['workflow_run']['head_sha']==sha
stage=next(x for x in (p/'verify-logs').iterdir() if x.is_dir() and x.name!='latest')
u=(stage/'unit.log').read_text();lines=u.splitlines();job=(p/'job-logs/check/7_Run verification.txt').read_text()
start=[];drain=[];costs=[];teststarts=[];tools=[]
for n,l in enumerate(lines,1):
 for prefix,target in [('runner: file lifecycle ',start),('runner: worker cost ',costs),('[verification-test-start] ',teststarts),('[verification-tool-phase] ',tools)]:
  if l.startswith(prefix):
   try:o=json.loads(l[len(prefix):]);o['line']=n;target.append(o)
   except ValueError:pass
   break
inner=next(x for x in start if x['type']=='runner:file-start')['pid'];supervisor=next(x for x in start if x['type']=='runner:file-start')['parentPid']
starts=[x for x in start if x['type']=='runner:file-start' and x.get('pid')==inner and x.get('parentPid')==supervisor]
planned=[x['entryFile'] for x in starts];planset=set(planned)
drains=[x for x in start if x['type']=='runner:file-drained' and x['entryFile'] in planset]
assert len(starts)==len(set(planned))==824 and len(drains)==len(set(x['entryFile'] for x in drains))==824
cs=[x for x in costs if (x.get('preImport') or {}).get('parentPid')==inner and x['entryFile'] in planset]
assert len(cs)==824
summary=re.findall(r'^runner: (\d+) passed, (\d+) failed; (\d+)/(\d+) planned file\(s\) completed$',u,re.M)[-1]
pending=re.findall(r'^runner: partial evidence; (\d+) skipped, (\d+) TODO;',u,re.M)[-1]
counts=dict(zip(['pass','fail'],map(int,summary[:2])));counts.update(dict(zip(['skip','TODO'],map(int,pending))))
assert counts=={'pass':4938,'fail':0,'skip':128,'TODO':388}
cleanup=[{'pid':int(m[0]),'elapsedMs':float(m[1]),'accepted':m[2]=='true'} for m in re.findall(r'^runner: post-exit group verification/reclamation: pid=(\d+); elapsedMs=([\d.]+); accepted=(true|false)$',u,re.M) if int(m[0])==inner]
startmap={x['entryFile']:x for x in starts};drainmap={x['entryFile']:x for x in drains};actualcost=[]
for o in cs:
 iv=o.get('interval');s=startmap[o['entryFile']];d=drainmap[o['entryFile']]
 actualcost.append({'entryFile':o['entryFile'].split('/vibe-fs/vibe-fs/')[-1],'pid':o.get('pid'),'status':o['status'],'reason':o.get('reason'),'startElapsedMs':s['elapsedMs'],'drainElapsedMs':d['elapsedMs'],'laneWallMs':d['elapsedMs']-s['elapsedMs'],'workerObservedInterval':iv,'preImport':o.get('preImport'),'exit':o.get('exit')})
actualcost.sort(key=lambda x:x['laneWallMs'],reverse=True)
ownedStarts=[x for x in tools if x.get('parentPid')==inner and x['phase']=='monitor-spawned']
groups={x['monitorPid']:[] for x in ownedStarts}
for x in tools:
 pid=x.get('monitorPid') if 'monitorPid' in x else x['pid']
 if pid in groups:groups[pid].append(x)
toolsummary=[]
for pid,events in groups.items():
 phases={x['phase']:x for x in events};times={k:v['at'] for k,v in phases.items()};required=['monitor-spawned','tool-spawned','tool-exited','group-drained','monitor-closed']
 o={'monitorPid':pid,'workerPid':events[0]['pid'],'phases':times,'complete':all(k in times for k in required)}
 if o['complete']:o.update({'monitorToToolMs':times['tool-spawned']-times['monitor-spawned'],'toolWallMs':times['tool-exited']-times['tool-spawned'],'exitToDrainMs':times['group-drained']-times['tool-exited'],'drainToCloseMs':times['monitor-closed']-times['group-drained'],'wholeMonitorMs':times['monitor-closed']-times['monitor-spawned']})
 toolsummary.append(o)
topworker={x['pid']:x['entryFile'] for x in actualcost if x.get('pid')}
for o in toolsummary:o['entryFile']=topworker.get(o['workerPid'],'unknown')
workerintervals=[x['workerObservedInterval'] for x in actualcost if x['workerObservedInterval']]
costreport={'sourceSha':sha,'scope':{'innerPid':inner,'supervisorPid':supervisor,'planned':824,'started':824,'drained':824,'active':[],'queued':[]},'counts':counts,'costStatus':dict(collections.Counter(x['status'] for x in cs)),'outerFileCosts':actualcost,'totals':{'laneWallMs':sum(x['laneWallMs'] for x in actualcost),'workerObservedWallMs':sum(x['wallMs'] for x in workerintervals),'workerOwnCpuUserMicros':sum(x['cpuUserMicros'] for x in workerintervals),'workerOwnCpuSystemMicros':sum(x['cpuSystemMicros'] for x in workerintervals)},'toolPhases':toolsummary,'cleanup':cleanup,'lastTopLevelFileDrain':max(drains,key=lambda x:x['elapsedMs']),'lastVerdict':'unknown: per-verdict IPC events are not persisted on successful drain; last file drain is separately recorded','ordinaryAssertionFailures':[],'limits':['Worker own CPU excludes children and does not separate imported module work from test bodies.','Nested deliberate red fixtures and invalid diagnostic snapshots are not outer assertion failures.','One complete original-budget drain does not prove stable throughput or identify a performance cause.','Remote post-job filesystem disposal is unknown; only logged owned group acceptance is authoritative.']}
(p/'unit-cost-analysis.json').write_text(json.dumps(costreport,indent=2)+'\n')
unknown={k:'unknown' for k in ['pass','fail','skip','TODO']};stages=[]
commands={'format:check':'npm run format:check','check':'npm run check','build':'node scripts/build.mjs --clean','unit':'node requirements/verification-system/tests/run.mjs','integration':'WXS_RELEASE=1 node requirements/verification-system/tests/integration/run.mjs','e2e':'WXS_TIER_RELEASE=1 node requirements/verification-system/tests/014.test.mjs','package':'node scripts/verify-package.mjs'}
for label,command in commands.items():
 m=re.search(r'  '+re.escape(label)+r' +(OK|FAIL\((\d+)\)) +([\d.]+)s',job)
 if m:o={'stage':label,'inputCommit':sha,'command':command,'durationSeconds':float(m[3]),'durationPrecision':'rounded to 0.1s by verify output','exitCode':int(m[2] or 0),'status':'pass' if m[1]=='OK' else 'fail','plannedFiles':'unknown','completedFiles':'unknown','activeFiles':'unknown','queuedFiles':'unknown','counts':unknown.copy(),'cleanup':'unknown'}
 else:o={'stage':label,'inputCommit':sha,'command':command,'durationSeconds':'not-run','exitCode':'not-run','status':'not-run','plannedFiles':'unknown','completedFiles':'not-run','activeFiles':'not-run','queuedFiles':'not-run','counts':{k:'not-run' for k in unknown},'cleanup':'not-run'}
 if label=='unit':o.update({'plannedFiles':824,'completedFiles':824,'activeFiles':0,'queuedFiles':0,'counts':counts,'cleanup':cleanup,'reason':'pending-proof policy; no outer assertion failures or truncation'})
 stages.append(o)
hashf=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
build=(stage/'build.log').read_text();total=float(re.search(r'FAIL  verify release +([\d.]+)s',job)[1]);digest=re.search(r'=== verify: release  inputs=([0-9a-f]+)',job)[1]
receipt={'auditedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Exact candidate head read-only CI audit; no test/build/CI retry performed by auditor','acceptanceBoundary':'Candidate ddb only. Strength fuse root-cause proof remains outstanding per parent. Not reusable for future final SHA.','run':{k:r.get(k) for k in ['id','html_url','status','conclusion','created_at','updated_at','run_attempt']},'source':{'expectedSha':sha,'actualSha':r['head_sha'],'shaMatches':True,'expectedTree':tree,'githubTree':c['tree']['sha'],'treeMatches':True,'checkoutLog':'job-logs/check/2_Run actions_checkout@v4.txt','inputDigestPrefix':digest,'fullInputDigest':'unknown; not uploaded','buildManifest':'unknown; not uploaded','artifactWorkflowHeadMatches':True},'environment':{'platform':'Linux x64, GitHub ubuntu-latest','node':'22.23.3','npm':'10.9.9','sdkSetupReported':'10.0.401','runtimeSetupReported':'10.0.12','fable':'5.13.0','fantomas':'6.3.0','NODE_TEST_CONCURRENCY':'2','UNIT_VERDICT_SILENCE_MS':'30000','scope':'All 824 requirement files planned/drained; no outer local filter reported'},'command':'NODE_TEST_CONCURRENCY=2 UNIT_VERDICT_SILENCE_MS=30000 node scripts/verify.mjs --release','durationSeconds':total,'exitCode':1,'stages':stages,'build':{'clean':True,'generation':1,'freshness':{'sources':1815,'artifacts':891},'registeredSurfaces':175,'linkedEmittedModules':835,'ownerCompileMs':44099,'fableCompilationMs':38611},'unit':{'planned':824,'started':824,'drained':824,'active':[],'queued':[],'counts':counts,'ordinaryAssertionFailures':[],'authoritativeSummary':'4938 passed, 0 failed; 824/824 planned files completed; 128 skipped, 388 TODO','terminationReason':'pending-proof policy','costStatus':costreport['costStatus'],'cleanup':cleanup,'details':'unit-cost-analysis.json'},'downloads':{'runMetadata':'run.json','jobsMetadata':'jobs.json','artifactsMetadata':'artifacts.json','completeJobZip':'job-logs.zip','completeJobZipSha256':hashf(p/'job-logs.zip'),'verifyArtifactZip':'verify-logs.zip','verifyArtifactSha256':hashf(p/'verify-logs.zip'),'githubArtifactId':a['id'],'githubArtifactDigest':a['digest'],'artifactDigestMatches':a['digest']=='sha256:'+hashf(p/'verify-logs.zip'),'extractedStageDirectory':str(stage.relative_to(p))},'conclusion':'Candidate CI remains failed due to pending proof policy. Format/static/clean build passed; all requirement files drained with zero outer assertion failures. Integration/E2E/package were not run. No whole-project green claim.','limits':costreport['limits']}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f"Exact candidate CI {r['id']}: {sha}\nGit tree {tree}; GitHub/checkout/artifact head verified.\nConclusion failure, unified {total}s exit1.\n"
for s in stages:text+=f"{s['stage']}: {s['status']}; duration seconds {s['durationSeconds']}; exit {s['exitCode']}; counts {s['counts']}\n"
text+=f"Unit: planned824 started824 drained824 active0 queued0; owned group {cleanup}.\nNo ordinary outer assertion failures. Failure is pending-proof policy (128skip/388TODO).\nOne original-budget complete drain is not stable throughput closure. Candidate only; Strength fuse remains unresolved.\n"
(p/'receipt.txt').write_text(text)
files=[]
for x in sorted(p.rglob('*')):
 if x.is_file() and x.name!='SHA256SUMS':files.append((x.relative_to(p).as_posix(),hashf(x),x.stat().st_size))
(p/'SHA256SUMS').write_text(''.join(h+'  '+f+'\n' for f,h,size in files))
print(text)
print('TOP WORKERS',json.dumps([{k:x[k] for k in ['entryFile','laneWallMs','workerObservedInterval']} for x in actualcost[:8]],indent=2))
print('TOOLS',len(toolsummary),'COMPLETE',sum(x['complete'] for x in toolsummary),'FILES',len(files),'BYTES',sum(x[2] for x in files))

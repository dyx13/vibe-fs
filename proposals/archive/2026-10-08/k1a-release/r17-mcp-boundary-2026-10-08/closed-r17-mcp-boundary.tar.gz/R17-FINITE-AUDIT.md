# R17 MCP 边界有限审计与归档提案

本文件由只读审查子 agent 编写，不改仓库、不运行测试或构建、不清理资源。正式运行由主线完成，以下结果来自已封口日志与输入收据；这是闭合前的有限证据，不能当作 Long Stroke 或全项目 release 通过。

## 差异范围

与 `r17-mcp-boundary/before/` 的原件逐项比较，现行 `long-stroke.toml` 只改 MCP 说明，并在原 `assertDelegationProtocolSurface` 后新增独立 `assertMcpFixtureBoundary`。更早的主线 `AssessmentCommitted gte=2 session="child"` 屏障、所有主线 turn、工具参数、routing、setup、事件上限和请求数均无变化。此次实际失败的屏障在该新增 custom 之前。

`long-stroke-oracles.mjs` 移去旧的“未知 MCP 工具必须呈现给 Manager”前提，增加独立连接与权限边界并注册到 CUSTOMS；另有 SameModel 说明缩短，不改其算法。没有改 Manager binder、较早的 oracle 或生产权限。现行 `014.test.mjs`、`long-stroke-protocol-fixture.mjs` 与交审 green 原件逐字节一致。

独立 MCP 边界要求实际 `GET /mcp` 成功，精确服务器 `wanxiang_fixture` 的状态为 `connected`，再以实际 durable decision 和 Host snapshot 确定的 Owner/Replica 检查各自实际 provider 请求，不允许呈现 fixture 工具。受控正式负控包括缺失、disabled、failed、错误服务器、HTTP 错误和 Owner/Replica 意外呈现。没有通过放开权限满足旧 oracle。

## 正式证据

| 阶段 | 构建代次 | pass/fail/cancel/skip/TODO | Node 汇总耗时 | 结论 |
| --- | --- | --- | --- | --- |
| 旧 oracle 正式 014 红 | 361 | 32/1/0/1/0 | 2762.517542ms | 旧 MCP presence 断言确定性失败；Host hooks 业务字段正控已通过 |
| 014/015 + capability-enforcement 007 | 362 | 43/0/0/1/0 | 3143.733667ms | 有限受控协议与权限证据；release E2E 因 tier 未启用而 skip |
| 实际 014 release E2E 文件 | 363 | 34/1/0/0/0 | 75337.394916ms | 实际 Long Stroke 在更早 Assessment 屏障失败，非 MCP 通过 |

正式红原错：`DELEGATE 4.1: the MCP fixture tool (deterministic semantic search hits) must appear on the owner wire`，`r17-mcp-red.log:185`。这不是缺 export 或空测试产生的假红。构建日志均明确记录 build ok 与 surface/module linkage 通过，但没有独立完整构建耗时和退出码收据，相关字段不得补猜。

实际 E2E 原错：`waitFact AssessmentCommitted not satisfied (need gte 2, got 1)`，`r17-mcp-boundary-e2e.log:268`。外层耗时 76813.039792ms，exit=1，signal=null，timedOut=false，inputsEqual=true。输入为 `ddb0c28cfbfa35762b2115f9609c85a296d68d1a` 加未提交差异的有限快照，preliminaryDirtyInput=true；不是该提交的干净 CI 收据。before/after digest 相同：`2539cfc6606e9e152520df7a6ccf94df683bf8a1b79e908d6968f386febeee32`。完整构建摘要与精确命令保存于 `e2e-receipt-summary.json`。

注意 `r17-mcp-boundary-e2e.log:94` 的 `[mcp] ... connected` 来自同一文件前面的受控正式用例，随后 `ok 31`，不是实际 Long Stroke 的 Host 状态。真实 release 测试为 `not ok 35`，在 MCP flow 之前停止。不得借该行填真实连接状态。

## 实际 ESpu2v 现场

精确根为 `/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/oc-e2e-ESpu2v`。Host 已停，本审计没有发 HTTP 请求。

SQLite 只读查询实际保存的 session.permission：两个 Replica 均为 `* deny` 加 `js-predictor allow`，分别属于原 Owner；Owner 的 session.permission 为 null。null 表示没有保存会话级覆盖，不能推断 agent 级权限为 allow，也不能代替实际运行时配置。完整只读选取与原 DB/WAL/SHM 哈希在 `actual-session-permissions.json`；三者前后字节/SHA均相同，但SHM mtime在读取期间变化，未声称metadata全稳定或排除其他并行读者。Host 日志没有 mcp/semble/wanxiang_fixture 状态文本；现行 OpenCode 成功连接本就不必写 INFO，因此日志缺失也不能证明断连。

实际 MCP status=unknown；实际独立 MCP custom=not-run；实际整条 MCP 连接+拒绝边界=not-proven。实际读取 read_probe.txt 的原生 read allow 是 Engineer 的记录，不是 MCP 或 Manager 授权证明。正式 ManagedAgentConfigSurface 的未知默认 deny 结果与源码/规范一致，但仍属于正式受控合同证明。

外层唯一已有资源收据为 monitorPid=26781、monitorObservation=ESRCH。没有本次完整 filesystem/mount/Host-owned resources 收据，资源清理填 unknown。ESpu2v 保留供其他子 agent 追因，本审计未备份整根、删除或 kill。不得据 monitor ESRCH 宣称整个资源树已清洁。

## 归档提案与剩余工作

建议主线在相关原件封口后，将 `archive-inventory.json` 中精确列出的正式日志、构建日志、outer JSON、两份 patch 和本报告复制到 `proposals/archive/2026-10-08/k1a-release/r17-mcp-boundary-2026-10-08/`，按 SHA-256 逐件复核。该清单只是提案，未写入仓库；没有按前缀复制目录或复制 live 日志。早期 `CAUSE-AND-SCOPE.md` 保留为执行前调查，不覆盖原文，不能把其中“尚未正式执行”的历史状态当作当前状态。

原件仍在的 SQLite、WAL/SHM、Host 日志若需随本次失败追因长期保留，应由有该资源归属的主线在确认停止与一致性后按精确路径备份，并补 inventory。当前仅保存本审计所需有限 permission 证据。

R17 可以登记“受控协议前提和独立边界正式红绿完成；真实 MCP 验收待主线较早失败修复后执行”。仍须按最终冻结输入完成真实 Long Stroke、全 release、独立未运行阶段和对应提交 CI；任何 skip、TODO、pending 或分批补跑不得改写为全项目绿。动态 MCP discovery、任意 MCP 语义授权、网络能力、完整 Host 权限验收不属于此项局部结论。

# R17 MCP 边界：原因与验收范围

本轮实际 E2E 原件：`/private/tmp/vibe-fs-oct8-alias-release/r16-root-protocol-e2e.log` / `.json`，31 pass / 1 fail / 0 skip / 0 TODO，19.084s，exit 1，输入摘要相同。Owner [3,4] 与 Replica [1,2] 已经过，失败是旧 oracle 要求未知 MCP 工具必须出现在 Manager wire。

`compileScenario` 的现行实现是 JS，`scenario-schema.js:922` 原样保留 `raw.setup`。`runCanary` → `setupScenario` → `ProcessHost.buildEnv` → `createIsolatedEnv` 的 mcpFixture/mcpServers 参数完整透传。没有证据支持“F# typed compiler 丢失未知 setup 字段”，该猜测明确排除。

能力合同与生产源一致：capability-enforcement WHAT[007]/[010]/[025] 及正式 007 控制要求未知工具默认 deny；`StaticTools.permissionObj` 先写 `*=deny`，`ManagedAgentConfig.assignOwnedFields` 替换托管 agent.permission；全局 `*=allow` 不会覆盖托管 agent 的后序 deny。Manager 只读能力经 `js-manager` 承载，不能给未知 MCP 特开权限来满足旧 oracle。

本机现行 OpenCode 源 `session/llm/request.ts` 的 resolveTools 经 `Permission.disabled` 合并 agent/session 权限过滤 schema。MCP 成功连接自身没有 INFO 日志，失败才产生 server-unavailable warning，因此 TBHuUa 的 opencode.log 无 mcp/semble 文本不能证明服务器没连接。实际连接状态必须通过运行中的 Host `GET /mcp` 验证，旧 TBHuUa 终局缺少该收据，记 unknown。

交付 TMP patch：

- `tests-red.patch`：仅扩正式 014。以真实 ManagedAgentConfigSurface 的权限投影和原 `assertDelegationProtocolSurface` 构造合法不呈现 MCP 的受控协议场景；旧 presence 断言应失败。另用原 registered Plugin fixture 的实际 tool.definition / before / after 证明 Unreviewed 同名业务字段无剥离、无校验、无键变动；这不授予工具执行权限。
- `boundary-green.patch`：把连接与权限观察迁到独立 `assertMcpFixtureBoundary`，flow 明确调用。实际 Host 状态必须成功且 exact `wanxiang_fixture.status=connected`；既有 durable decision/真实 Host snapshot 识别的两 Owner、两 Replica 都必须有实际 chat 请求，并且任何这些请求不得呈现 fixture 工具。正式受控 port 负控覆盖 missing / disabled / failed / wrong-server / HTTP 错误、Owner 意外呈现、Replica 意外呈现。
- 原协议 oracle 继续逐工具按实际三态 classifier 与参与参数合同验证；保留原 SSE source 同批、同 session/callId/args/result 严格保持、foreign-source/参数改写负控。只移走与生产权限冲突的 MCP presence 前提。
- 受控 protocol fixture 的 custom_tool 仅是 Unreviewed 业务工具，不再借 semantic-search 描述假扮真实 MCP。业务字段透传正控仍在。

本 subagent 未执行正式红绿或 E2E，不填新的 pass/fail。由主线执行后登记。未知 MCP 动态 discovery、任意 MCP 的语义能力映射、网络能力、完整 Host 权限验收和全项目 release 均不在此有限改动的通过结论内。生产权限、需求、tier、count、预算保持原值。

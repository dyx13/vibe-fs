from pathlib import Path
import collections
import datetime
import hashlib
import json
import os
import plistlib
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import traceback

ROOT = Path('/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/verification-repository-fable-project-cqpeNB')
BASE = Path('/private/tmp/vibe-fs-oct8-release-65a70d0fd-readonly-audit')
OUT = BASE / 'cqpeNB-owned-cleanup'
LOG = Path('/private/tmp/vibe-fs-oct8-release-65a70d0fd/supplemental-six-physical016.log')
RETAINED = BASE / 'six-physical-retained-root-readonly.json'
SIX = LOG.with_suffix('.json')
EXPECTED = (16777231, 159231739, 501)
REPOSITORY = Path('/Users/yuanxi/Workwork/vibe-fs')
AUTHORIZED_DOCS = {
    'proposals/K1A与全项目release验收-2026-10-08.md',
    'proposals/TODO施工总计划-2026-10-03.md',
    'proposals/U0-A1-Casebook-K1AF施工卡-2026-10-08.md',
    'requirements/verification-system/tests/README.md',
}

def identity(path):
    s = path.lstat()
    return dict(dev=s.st_dev, ino=s.st_ino, uid=s.st_uid,
                mode=stat.S_IMODE(s.st_mode), isDirectory=stat.S_ISDIR(s.st_mode),
                isSymlink=stat.S_ISLNK(s.st_mode))

def require_owned(path):
    value = identity(path)
    if (value['dev'], value['ino'], value['uid']) != EXPECTED or not value['isDirectory'] or value['isSymlink']:
        raise RuntimeError(f'Exact owned root identity mismatch: {value}')
    return value

def digest(path):
    before = path.lstat()
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as file:
        opened = os.fstat(file.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino) or not stat.S_ISREG(opened.st_mode):
            raise RuntimeError(f'Regular file identity changed before reading: {path}')
        h = hashlib.sha256()
        for block in iter(lambda: file.read(1024 * 1024), b''):
            h.update(block)
        after = os.fstat(file.fileno())
    current = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_mode', 'st_uid')
    if any(getattr(before, k) != getattr(after, k) or getattr(before, k) != getattr(current, k) for k in keys):
        raise RuntimeError(f'File changed while hashing: {path}')
    return h.hexdigest()

def inventory(root):
    entries = []
    def visit(path, relative):
        s = path.lstat()
        entry = dict(path=relative, dev=s.st_dev, ino=s.st_ino, uid=s.st_uid,
                     mode=stat.S_IMODE(s.st_mode), mtimeNs=s.st_mtime_ns, ctimeNs=s.st_ctime_ns)
        if stat.S_ISLNK(s.st_mode):
            entry.update(kind='symlink', target=os.readlink(path))
        elif stat.S_ISREG(s.st_mode):
            entry.update(kind='file', bytes=s.st_size, sha256=digest(path))
        elif stat.S_ISDIR(s.st_mode):
            entry['kind'] = 'directory'
        else:
            raise RuntimeError(f'Unexpected special object; no silent skip: {path}')
        entries.append(entry)
        if entry['kind'] == 'directory':
            for child in sorted(path.iterdir(), key=lambda p: p.name):
                visit(child, child.name if relative == '.' else relative + '/' + child.name)
    visit(root, '.')
    return entries

def content(entries):
    return [{k: entry[k] for k in ('path', 'kind', 'mode', 'uid', 'bytes', 'sha256', 'target') if k in entry} for entry in entries]

def write_json(path, value):
    with path.open('x') as file:
        json.dump(value, file, ensure_ascii=True, indent=2)
        file.write('\n')

def invoke(command):
    done = subprocess.run(command, capture_output=True, timeout=30)
    return dict(command=command, exitCode=done.returncode,
                stdout=done.stdout.decode('utf-8', 'replace'), stderr=done.stderr.decode('utf-8', 'replace'))

def git_identity():
    value = {key: subprocess.check_output(command, cwd=REPOSITORY, text=True).strip() for key, command in {
        'commit': ['git', 'rev-parse', 'HEAD'], 'tree': ['git', 'rev-parse', 'HEAD^{tree}'],
        'status': ['git', '-c', 'core.quotepath=false', 'status', '--porcelain=v1'],
    }.items()}
    for key, command in {
        'changedPaths': ['git', 'diff', 'HEAD', '--name-only', '-z'],
        'stagedPaths': ['git', 'diff', '--cached', '--name-only', '-z'],
        'untrackedPaths': ['git', 'ls-files', '--others', '--exclude-standard', '-z'],
    }.items():
        value[key] = [path for path in subprocess.check_output(command, cwd=REPOSITORY).decode().split('\0') if path]
    for key, command in {
        'workingDiffSha256': ['git', 'diff', '--binary'],
        'stagedDiffSha256': ['git', 'diff', '--cached', '--binary'],
    }.items():
        value[key] = hashlib.sha256(subprocess.check_output(command, cwd=REPOSITORY)).hexdigest()
    return value

def require_repository_identity(value):
    if value['commit'] != '65a70d0fd4c40eb917bc1056875ee842e91c39c3' or value['tree'] != '4bd3d120034e4e2ab9f7e81804312c8ad468fb9c':
        raise RuntimeError('Repository HEAD/tree changed from exact authorized input')
    if value['untrackedPaths'] or not set(value['changedPaths']).issubset(AUTHORIZED_DOCS) or not set(value['stagedPaths']).issubset(AUTHORIZED_DOCS):
        raise RuntimeError('Repository differences exceed the four concurrently authorized documentation paths')

def process_evidence():
    events = []
    for number, line in enumerate(LOG.read_text().splitlines(), 1):
        marker = '[verification-tool-phase] '
        if marker in line:
            events.append({'line': number, **json.loads(line.split(marker, 1)[1])})
    selected = [e for e in events if e['phase'] == 'monitor-spawned' and e.get('pid') == 13768 and e.get('parentPid') == 13767]
    if not any(e.get('executable', '').startswith(str(ROOT) + '/') for e in selected):
        raise RuntimeError('No exact original fixture path/native worker ownership evidence')
    monitors = {e['monitorPid'] for e in selected}
    relevant = [e for e in events if e.get('monitorPid') in monitors or e.get('pid') in monitors]
    tools = {e['toolPid'] for e in relevant if 'toolPid' in e}
    pids = {13766, 13767, 13768} | monitors | tools
    groups = {13767} | tools
    observed = []
    for kind, values in [('pid', pids), ('group', groups)]:
        for value in sorted(values):
            try:
                os.kill(value if kind == 'pid' else -value, 0)
                observation = 'present; cannot prove this lifetime remains owned'
            except ProcessLookupError:
                observation = 'ESRCH'
            except PermissionError:
                observation = 'EPERM; unknown'
            observed.append(dict(kind=kind, id=value, observation=observation))
    if any(e['observation'] != 'ESRCH' for e in observed):
        raise RuntimeError(f'Owned attempt terminal identity not absent: {observed}')
    return dict(originalNativeWorker=13768, originalActualTool=13767, originalMonitor=13766,
                selectedSpawns=selected, relatedToolPhases=relevant, observations=observed)

def resources(path, additional_paths=()):
    process = process_evidence()
    lsof = invoke(['lsof', '-nP', '+D', str(path)])
    if lsof['exitCode'] != 1 or lsof['stdout'] or lsof['stderr']:
        raise RuntimeError(f'Exact root open-file inspection not empty: {lsof}')
    hdiutil = invoke(['hdiutil', 'info', '-plist'])
    if hdiutil['exitCode'] != 0 or hdiutil['stderr']:
        raise RuntimeError(f'Image inspection failed: {hdiutil}')
    image_data = plistlib.loads(hdiutil['stdout'].encode())
    roots = [str(ROOT), str(path)] + [str(p) for p in additional_paths]
    selected_images = [image for image in image_data.get('images', []) if any(root in json.dumps(image) for root in roots)]
    mounts = invoke(['mount'])
    selected_mounts = [line for line in mounts['stdout'].splitlines() if any(root in line for root in roots)]
    if selected_images or mounts['exitCode'] != 0 or mounts['stderr'] or selected_mounts:
        raise RuntimeError('Exact root image or mount remains, or inspection is unknown')
    return dict(process=process, lsof=lsof, hdiutil=hdiutil, selectedImages=selected_images,
                mount=mounts, selectedMountLines=selected_mounts)

stage = sys.argv[1]
if stage not in ['backup', 'cleanup']:
    raise RuntimeError('Only backup or cleanup stage is supported')
OUT.mkdir(mode=0o700, exist_ok=True)
if OUT.is_symlink() or not OUT.is_dir() or OUT.stat().st_uid != 501:
    raise RuntimeError('Private receipt directory ownership is not exact')
started = time.monotonic()
receipt = {'stage': stage, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exactOriginalRoot': str(ROOT), 'expectedIdentity': EXPECTED,
           'authority': 'Root authorized only exact old cqpeNB allocated by native13768/actual13767/monitor13766; no new parent6 roots or tracked files',
           'concurrentDocumentationAuthority': sorted(AUTHORIZED_DOCS),
           'inputsBefore': git_identity(), 'actions': []}
try:
    require_repository_identity(receipt['inputsBefore'])
    original_attempt = json.loads(SIX.read_text())
    if original_attempt.get('monitorPid') != 13766 or original_attempt.get('actualTool', {}).get('pid') != 13767 or not original_attempt.get('actualTerminalObservedAt'):
        raise RuntimeError('Original six-parent receipt does not bind the selected actual attempt')
    receipt['originalAttempt'] = {key: original_attempt.get(key) for key in ['monitorPid', 'actualTool', 'actualTerminalObservedAt', 'terminal', 'toolDurationMs', 'monitorObservation', 'actualToolObservation']}
    if stage == 'backup':
        receipt['beforeIdentity'] = require_owned(ROOT)
        receipt['beforeResources'] = resources(ROOT)
        receipt['proofCopies'] = []
        for source in [LOG, RETAINED, SIX]:
            destination = OUT / source.name
            source_hash = digest(source)
            shutil.copy2(source, destination, follow_symlinks=False)
            destination_hash = digest(destination)
            if destination_hash != source_hash:
                raise RuntimeError('Provenance copy SHA readback mismatch')
            receipt['proofCopies'].append(dict(source=str(source), backup=str(destination), sha256=source_hash))
        print('Hashing complete exact source tree', flush=True)
        source = inventory(ROOT)
        write_json(OUT / 'source-before-inventory.json', source)
        backup_parent = Path(tempfile.mkdtemp(prefix='vibe-fs-cqpeNB-owned-backup-', dir='/private/tmp'))
        backup = backup_parent / 'root'
        if backup_parent.stat().st_dev != EXPECTED[0]:
            raise RuntimeError('Backup must use the same APFS device for independent clone attempt')
        receipt['backupParent'] = str(backup_parent)
        receipt['backupRoot'] = str(backup)
        print('Cloning only exact owned source with cp -cRp', flush=True)
        copied = subprocess.run(['cp', '-cRp', str(ROOT), str(backup)], capture_output=True, text=True, timeout=60)
        receipt['cloneCommand'] = dict(command=['cp', '-cRp', str(ROOT), str(backup)], exitCode=copied.returncode, stdout=copied.stdout, stderr=copied.stderr)
        if copied.returncode != 0 or copied.stdout or copied.stderr:
            raise RuntimeError('Clone/copy failed; no silent skip or fallback accepted')
        print('Reading SHA256 of every backup regular file', flush=True)
        backed = inventory(backup)
        write_json(OUT / 'backup-readback-inventory.json', backed)
        if content(source) != content(backed):
            raise RuntimeError('Complete file/directory/link/mode/owner/SHA readback mismatch')
        for original, copied in zip(source, backed):
            if original['kind'] == 'file' and (original['dev'], original['ino']) == (copied['dev'], copied['ino']):
                raise RuntimeError('Backup file is not an independent inode')
        receipt['afterSourceIdentity'] = require_owned(ROOT)
        receipt['backupIdentity'] = identity(backup)
        receipt['counts'] = dict(collections.Counter(entry['kind'] for entry in source))
        receipt['regularBytes'] = sum(entry.get('bytes', 0) for entry in source)
        receipt['readbackEqual'] = True
        receipt['sourceManifestSha256'] = digest(OUT / 'source-before-inventory.json')
        receipt['backupManifestSha256'] = digest(OUT / 'backup-readback-inventory.json')
        receipt['inputsAfter'] = git_identity()
        require_repository_identity(receipt['inputsAfter'])
        receipt['repositoryStatusUnchanged'] = receipt['inputsBefore'] == receipt['inputsAfter']
        receipt['actions'] = ['Exact provenance files copied and SHA read back', 'Every source regular file SHA256 read', 'cp -cRp independent same-device backup', 'Every backup regular file SHA256 read and compared; symlinks and directories included']
    elif stage == 'cleanup':
        previous = json.loads((OUT / 'backup-receipt.json').read_text())
        if previous.get('readbackEqual') is not True or previous.get('failure'):
            raise RuntimeError('No complete successful backup receipt')
        source = json.loads((OUT / 'source-before-inventory.json').read_text())
        backup = Path(previous['backupRoot'])
        if identity(backup) != previous['backupIdentity']:
            raise RuntimeError('Backup root identity changed')
        receipt['backupRoot'] = str(backup)
        receipt['backupReceiptSha256'] = digest(OUT / 'backup-receipt.json')
        receipt['beforeIdentity'] = require_owned(ROOT)
        receipt['beforeResources'] = resources(ROOT)
        quarantine_parent = Path(tempfile.mkdtemp(prefix='vibe-fs-cqpeNB-owned-disposal-', dir='/private/tmp'))
        quarantine = quarantine_parent / 'root'
        if quarantine_parent.stat().st_dev != EXPECTED[0]:
            raise RuntimeError('Atomic move requires same device')
        require_owned(ROOT)
        os.rename(ROOT, quarantine)
        receipt['actions'].append('Atomic move of exact owned root into private disposal directory')
        receipt['quarantineRoot'] = str(quarantine)
        receipt['movedIdentity'] = require_owned(quarantine)
        receipt['movedResources'] = resources(quarantine, [backup])
        print('Re-reading every moved source file before disposal', flush=True)
        moved = inventory(quarantine)
        write_json(OUT / 'source-after-atomic-move-inventory.json', moved)
        if content(source) != content(moved):
            raise RuntimeError('Moved source differs from complete verified backup; preserve quarantine')
        receipt['movedContentEqualToVerifiedBackup'] = True
        receipt['movedManifestSha256'] = digest(OUT / 'source-after-atomic-move-inventory.json')
        receipt['immediateBeforeDeletionIdentity'] = require_owned(quarantine)
        shutil.rmtree(quarantine)
        os.rmdir(quarantine_parent)
        receipt['actions'].append('Removed only reverified cqpeNB inode from private disposal directory')
        receipt['originalRootAbsent'] = not ROOT.exists() and not ROOT.is_symlink()
        receipt['quarantineRootAbsent'] = not quarantine.exists() and not quarantine.is_symlink()
        receipt['backupIdentityAfter'] = identity(backup)
        receipt['backupRetained'] = True
        receipt['finalResources'] = resources(backup, [quarantine])
        receipt['inputsAfter'] = git_identity()
        require_repository_identity(receipt['inputsAfter'])
        receipt['repositoryStatusUnchanged'] = receipt['inputsBefore'] == receipt['inputsAfter']
        if not receipt['originalRootAbsent'] or not receipt['quarantineRootAbsent']:
            raise RuntimeError('Exact owned root removal not confirmed')
    else:
        raise RuntimeError('Only backup or cleanup stage is supported')
    receipt['succeeded'] = True
except BaseException as error:
    receipt['succeeded'] = False
    receipt['failure'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
finally:
    receipt['durationMs'] = (time.monotonic() - started) * 1000
    receipt['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write_json(OUT / (stage + '-receipt.json'), receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key in ['stage', 'succeeded', 'failure', 'durationMs', 'backupRoot', 'counts', 'regularBytes', 'originalRootAbsent', 'quarantineRootAbsent']}, ensure_ascii=False), flush=True)
if not receipt['succeeded']:
    raise SystemExit(1)

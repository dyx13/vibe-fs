# 65a CI throughput audit

The official run for `65a70d0fd4c40eb917bc1056875ee842e91c39c3` failed at its original 300000ms unit boundary: 539/824 files drained, two active, 283 queued. All four aggregate verdict counts remain unknown. The local 824/824 result and the earlier 8d0 CI result do not cover this failure.

The final active files were participant-identity/008 and /009. Their admission times were 299158.633ms and 299211.138ms. They identify where the backstop arrived; these logs do not identify them as the cause.

The two file slots were occupied for 598316.964ms of the available 600000ms (99.719%). The remaining 1683.036ms includes startup and handoffs. This is slot occupancy, not CPU utilization. No material unused queue capacity explains the cutoff.

Across 537 files with valid costs in both official runs:

| Observation | 8d0 CI | 65a CI |
| --- | ---: | ---: |
| Summed own-worker wall | 358524.186ms | 563211.610ms |
| Summed own-worker CPU | 326585490us | 532894426us |
| Median current/baseline wall ratio | — | 1.7173 |
| Median current/baseline CPU ratio | — | 1.6714 |

536/537 files used more than 1.25 times the own-worker CPU. Excluding 016 leaves essentially the same median ratios. 536 of these 537 test entry files are byte unchanged; the changed entry is 006. Shared imports can still differ, so unchanged entry files are not a proof of identical semantic work. Own-worker CPU excludes child tools, and the two invalid observations plus two missing exits are excluded.

Before unit began, format, static checks and clean build also took more time: 6.7→11.0s, 4.5→7.9s and 50.9→83.4s. This is additional observation of broad cost growth, not a profile identifying its cause.

The complete CI environment was different. The setup logs report:

| Identity | 8d0 CI | 65a CI |
| --- | --- | --- |
| Runner image | 20261004.327.1 | 20260927.320.1 |
| Provisioner | 20261002.596 | 20260901.588 |
| Runner | 2.337.0 | 2.337.0 |
| OS release | Ubuntu 24.04.5 | Ubuntu 24.04.5 |
| Region | westus3 | westus3 |

Both receipts report Node 22.23.3, npm 10.9.9, Fable 5.13.0 and setup SDK 10.0.401. No independent `dotnet --version`, complete archive identity or raw build manifest was uploaded. Equal reported tool versions do not make these complete environments equal.

The different image and provisioner are proved confounders. They do not prove a particular image, CPU frequency, quota, GC or filesystem condition caused the slowdown. No controlled profile identifies a redundant product operation. No additional simple runner fix is proved, and priority changes cannot be presented as closing this broad cost increase.

Read-only evidence is in `ci65a-cross-run-cost-readonly.json` and `ci65a-throughput-conclusion-readonly.json` beside this file. The original CI artifact and receipt remain in `/private/tmp/vibe-fs-oct8-alias-release/ci-65a70d0fd4c4-37783171051/`. No source, budget, concurrency, tier or assertion was changed by this audit; no test, build or CI was rerun.

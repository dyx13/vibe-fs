# 65a unit final reconciliation

Frozen commit `65a70d0fd4c40eb917bc1056875ee842e91c39c3`, tree `4bd3d120034e4e2ab9f7e81804312c8ad468fb9c`, 4676 inputs, digest `bf3b6643d2e544b8489acae892ebccac335dee299ef40a4b4728730683cb47f3`; clean before and after. Actual clean build generation 375; generation 374 was the pre-unified snapshot. Inputs and tools are unchanged.

824/824 drained, 4971 pass, 0 fail, 127 skip, 388 TODO. The original 300000ms backstop was not reached. Last drain was at 286484.205ms, stage duration 287.0s; the unified command took 337975.986ms and exited 1 under pending-proof policy.

822 valid worker costs: 542117.750ms concurrent wall and 317564300us CPU. Two invalid nested-supervisor observations (021, capability019) remain unknown and excluded.

016 was admitted at 13893.399ms; own wall was 168545.911ms, own CPU 41866490us. Versus 8d0, 822 matched own-worker wall sums increased 11323.867ms, of which 016 accounts for 10832.729ms (95.66%); CPU decreased 478363us overall. Different frozen inputs prevent claiming environment or archive cost as the isolated cause.

Group 44498 cleanup was accepted in 18.176ms; 203/203 owned monitors closed; all 1232 exact known PIDs were ESRCH. This scope excludes global process, filesystem and mount claims.

The older ddb 300-second truncation and its unproven cause are preserved. This complete unit run is not full project acceptance.

# 65a70d0fd source candidate: closed whole-project matrix (FAILED)

Input: commit `65a70d0fd4c40eb917bc1056875ee842e91c39c3`, tree `4bd3d120034e4e2ab9f7e81804312c8ad468fb9c`, clean4676inputs, digest `bf3b6643d2e544b8489acae892ebccac335dee299ef40a4b4728730683cb47f3`. Local tools Node22.23.3/npm11.12.1/SDK10.0.302/Fable5.13.0. Frozen pre-build gen374 is historical; actual unified clean build is gen375, manifestSHA `d4befcb65951698491ef8dfa5589e344c31ceb36c952124fe2789ecc5e0d3341`.

Read-only TMP audit only: no repository edits, no tests/builds, no cleanup. Exact root tool authority and closed wrapper/source receipts are linked from `current-matrix.json`; live snapshots are not seals.

| Phase | Time | Exit | Planned / completed | Pass / fail / skip / TODO | Scope and conclusion |
| --- | --- | --- | --- | --- | --- |
| Actual direct repository format | 4.12s real | 0 | N/A | N/A | Tool session57735, actual Fantomas scan; not cached output |
| Actual direct repository static gates | 3.58s real | 0 | N/A | N/A | Tool session3551, actual static scan |
| Unified format | 4.1s rounded step | 0 | N/A | N/A | Ran1/skipped0; wireit3.9s |
| Unified check | 3.8s rounded step | 0 | N/A | N/A | Ran1/skipped0; wireit3.7s |
| Unified clean Fable build | 41.4s rounded step | 0 | N/A | N/A | `node scripts/build.mjs --clean`; gen375 |
| Unified requirements | 286.46s summary wall / 604.15s cumulative test; step287.0s | 1 | 824 / 824 | 4971 / 0 / 127 / 388 | Pending-proof policy only; skip/TODO are not passes |
| Unified integration / E2E / package | not-run | not-run | 44 / 0;1 / 0;N/A | not-run | Stopped after unit nonzero |
| Independent integration parent | entry315296.936917ms / wrapper317714.515875ms | 1 | 44 / 43 | unknown / unknown / unknown / unknown | Original300000ms cutoff; active016, queued0; no authoritative aggregate verdict |
| Independent integration distribution | child0.2s rounded | 1 | 1 / 1 | 3 / 0 / 0 / 1 | Pending-proof policy; independent of main44 parent verdict |
| Independent integration harness | child14.0s; summary13.8s | 0 | Cases plan/completion unknown in summary | 292 / 0 / unknown / unknown | Original readiness lower-bound assertion passed; no skip/TODO summary |
| Independent release LongStroke E2E | entry19408.221792ms / TAP19033.963375ms | 0 | 1 / 1 | 35 / 0 / 0 / 0 | Cancelled0; journal470/699,SSE2235/3351 |
| Independent real package | entry5012.586584ms | 0 | N/A | unknown / unknown / unknown / unknown | Non-TAP actual command succeeded without a four-count summary. Real pack/unpack/isolatedconsumer;2073members12,504,715B;tarSHA9fd7eb8e844ea2aeb01c471ae71a7ef1e06c8d14bf93bfd2038ed43374858eec |
| Supplemental six physical016 parents | tool300068.787584ms / wrapper302723.582584ms | SIGKILL, no integer exit | 6 / 5 terminal parents;6entered | unknown / unknown / unknown / unknown | Original300000ms cutoff, no native TAP summary; original per-leaf180000 and no CLI whole-file timeout; parent6 had4childpasses but no parent final verdict |
| Supplemental unfinished physical parent6 | tool126021.170167ms / wrapper128708.694667ms | 0 | 1 / 1 parent and file | 5 / 0 / 0 / 0 | Cancelled0;1parent+4children, same frozen input, does not replace prior cutoff |
| Exact official CI37783171051/job113331132750 | fmt11s/check7.9s/build83.4s/unit300.7s | 1 | 824 / 539 | unknown / unknown / unknown / unknown | Original300000ms cutoff;2active participant-identity008/009,283queued; later integration/E2E/package not-run |

Unified total entry337975.986166ms, wrapper339983.873083ms, exit1, acceptedfalse. Commands and original verificationSteps env/outer budgets are preserved in `current-matrix.json` and exact closed receipts. All four closed local wrappers independently match frozen commit/tree/digest/4676inputs/clean status and tools; log SHA matches, independent stage manifests remain identical gen375. No prior8d0 or dirtyR20 narrow receipt is used as this candidate's validation.

Resource authority is finite: unified inner44498 accepted18.176ms,203/203 toolmonitors have all closure phases,1232exactPID observations ESRCH. Independent integration inner1474 accepted16.918ms,46exactknownPID ESRCH; quiet logs provide0toolmonitor records, not proof that no tools existed. Wrapper monitors44099/1470/11814 observed ESRCH only for their recorded scopes. Six physical monitor13766 and actualtool13767 pid/group ESRCH; exact owned HOME removed. Its original readonly Fable root `.../verification-repository-fable-project-cqpeNB` remains (dev16777231/ino159231739/uid501, directory nonlink); hdiutil/mount show0images/mounts at that exact root, no directory deletion or ownership-wide filesystem proof. Original passed parent5rootONNoc0 absent. No unknown/current parent6 root touched.

Official CI resources: outergroup3057 acceptedtrue9.134ms,201tool groups drained and monitorclosed0; remote individualPID ESRCH/fullfilesystem removal unknown. Sealed38files11,653,378B independently verified35inventory entries,37SHA256SUMS entries, bothZIP CRC and published artifact digest. Remote tools differ (npm10.9.9/setup SDK10.0.401 observed); full remote input digest and manifest bytes not uploaded, remain unknown. Last active files are not established root cause;537complete/2invalid/2missing cost records do not provide a complete cost total or assertion verdict.

Whole-project acceptance is **not complete**. Local unit pending-proof, actual CI truncation and actual integration truncation remain separate failures. Further finite physical coverage cannot be assembled into a once-through integration/fullrelease pass. Preserve388TODO/skip boundaries, opening-append/Root-change unproved formal boundary and historical/stable-throughput unknown cause. Original8d0 mixed failures remain immutable historical receipts.

Final exact cqpeNB cleanup: complete independent4.56GB APFS backup with20724regularfiles/2038dirs/331symlinks fully SHA/mode/owner/target verified; atomic-move source readback matched. Backup14900.476750ms and cleanup7896.322000ms; originalinode and quarantine absent,139exactPID/PGID observations ESRCH,exactlsof empty,no relatedimage/mount. Backup remains TMP; only14sealedmetadatafiles are archived. Original retained-root observation above is historical before this precise cleanup, not current presence. No all-filesystem/remoteCI cleanup claim.

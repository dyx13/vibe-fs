# 65a70d0fd read-only matrix review

Frozen source candidate: `65a70d0fd4c40eb917bc1056875ee842e91c39c3`, tree `4bd3d120034e4e2ab9f7e81804312c8ad468fb9c`, 4676 inputs, digest `bf3b6643d2e544b8489acae892ebccac335dee299ef40a4b4728730683cb47f3`.

This TMP audit does not execute tests/builds, seal live evidence, modify tracked files, kill processes or remove resources. Historical 8d0 failure and dirty/scoped R20 proof remain separate inputs.

- Preserve actual direct format/static scan tool authority (exit0, 4.12s / 3.58s) separately from unified wireit cache output.
- Resolve unified step logs to this run's exact directory. Read actual clean-build after-manifest generation/digests; frozen prebuild gen374 is not the new build receipt.
- For every stage retain command, original env/tier/outer timeout, inner budget, wall/test time distinction, exit and timeout/signal, planned/completed files and authoritative pass/fail/skip/TODO. No authority => unknown; unexecuted => not-run; non-TAP pack/build/check => N/A.
- Unit exact registered plan has 824 unique entries. Match parent innerPid and post-cleanup parent summary; nested negative runner output/summary is expected fixture evidence, not parent failures. Keep pending-proof exit1 distinct from assertions, timeout/cancel and environmental failure.
- Integration exact registered parent plan has 44 unique entries. Preserve original 300000ms limit, active/queued set, admitted and drained counts, first/last actual progress and worker costs if truncated. Distinct distribution and harness terminal summaries must not fabricate a parent verdict.
- Distribution pending policy can fail with no failed assertion. Harness summary omits skip/TODO; retain unknown absent authority. Do not infer zero from a helper's synthesized JSON.
- Independent integration/E2E/package can supply missing stage evidence, but cannot overwrite unified nonzero or be called a once-through full release pass. Require same commit/tree/digest/tools and fresh same manifest before/after each stage.
- Six physical 016 supplements must use this exact new input. Keep original 300000ms owner backstop and PER_TEST_TIMEOUT_MS=180000; no CLI `--test-timeout` applying 180000 to the entire file. Retain explicit six body titles, actual tested and filtered counts, foreign scopes, signal/cancel/not-run. A subset is not full 016 or full integration acceptance.
- Resource table is limited to exact original lifecycle identities, observed ESRCH and admitted ownership evidence. Monitor ESRCH, accepted inner process group and null wrapper cleanup failure do not prove files, mounted readonly views, Host scratch or other process groups reclaimed. All mount/filesystem proof remains unknown until independently recorded by exact owner.
- Cost invalid/unsupported observations are not test failures. One within-budget whole run cannot close historical environment cause or stable-throughput TODO.
- Check exact final candidate CI job/run/artifact head and tree, authority counts, not-run later phases, duration and original budgets. Never borrow old8d0 official CI receipts. If later docs-only commit changes source SHA, explicitly distinguish source candidate receipts and exact final CI.
- Preserve opening-append during Root-replacement unproven formal boundary and all retained requirement skip/TODO. Do not reopen 0e949fb7b busy-resume or finite Fetch K1-A work without new counterexample.

All terminal evidence still requires a source inventory with SHA256 and read-back archive proof when root authorizes final archive; this audit's live snapshot hashes do not seal files.

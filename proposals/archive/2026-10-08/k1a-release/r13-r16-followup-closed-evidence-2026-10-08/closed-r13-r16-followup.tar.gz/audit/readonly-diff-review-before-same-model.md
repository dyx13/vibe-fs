# R13–R16 当前差异只读复核

本次仅阅读当前未提交差异，不执行测试或构建，不修改仓库。源码在其他施工者继续更新，本文是该时点调查，不能代替最终冻结输入的验收。

- R13 的 Stopped 分支已用明确 else 隔离全部下游；提取的 current-horizon 能力组只包含 pair/grounding/delegation，既有顺序未重排。fuse 诊断复用原 reason，没有新增状态、解除熔断或绕过 missing-anchor/digest 负控。
- R14 的 payload 查询复用原 extractFactCasesAndIdentities；旧递归算法已经移除，实际顶层 Strength 与嵌套 JournalEnvelope 使用同一条提取路径。
- R15 从实际 HTTP model header记录非枚举 providerID，原 body model 仍保留裸 ID；三个 provider 共 URL时没有从 URL 猜身份或给裸 model 自动补 test 前缀。
- R16 只有同模型 fixture phase 存在期间覆盖 Manager/readonly-delegate 路由，已失败的 test provider明确拒绝；无 phase 时保原 candidates/failed/previous 分支。恢复 turn 的 internal 与 lane 不能并存，该中间夹具错误已被真实 compiler 拒绝，当前 lane已移除；must及500/400/epoch/ceilings保留。
- 当前 same-model oracle 尚调用旧 delegatingOwnerSessions。它依赖另一套 PARTICIPATING_TOOLS/estimateOfCall/isAuthenticOwnerPositiveEstimateRequest，最新 Replica js-predictor batch会令发现owner为0；同时仍按整个Session及所有owner×Replica比较。这是明确残留路径，已通知root及unit_cost_rootcause，须由same-model正式反例→原decision/root helper迁移后删除四段旧代码。toolNameOfCall仍供协议oracle使用，应保留。
- 新 protocol 观察从实际写完的 SSE delta重建源batch，而不是读取后来可能变化的脚本响应。正式fixture另独立解码已写字节作对照。源batch完成仅表示SSE写完；如果后继实际Host取消暴露“已发call但工具结果未完成”的分支，须按真实完成证据区分，不将原合法取消当成必须成功执行所有call。当前没有该分支的实际失败证据，仍待真实E2E，不能先修改或削弱断言。

当前已封口局部证据：gen351相关279tests、270pass/0fail/1skip/8TODO；gen356的014/015共35tests、34pass/0fail/1skip/0TODO。same-model正式回归、实际Host E2E、最终全仓与精确SHA CI均不由本文授绿。

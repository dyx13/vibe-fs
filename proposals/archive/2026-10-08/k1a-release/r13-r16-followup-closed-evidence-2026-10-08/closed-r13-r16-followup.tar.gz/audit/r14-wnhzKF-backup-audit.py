from pathlib import Path
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
import plistlib
import shutil
import stat
import subprocess

base = Path('/private/tmp/vibe-fs-oct8-alias-release')
temporary = Path('/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T')
root = temporary / 'oc-e2e-wnhzKF'
destination = base / 'r14-wnhzKF-owned-evidence'
destination.mkdir(exist_ok=False)
run_id = '1791455606115-8821-2sm7ms'
ledger = temporary / 'wanxiang-ledger' / (run_id + '.jsonl')
marker = temporary / 'wanxiang-ledger' / (run_id + '.run')

def stamp():
    return datetime.now(timezone.utc).isoformat()

def identity(path):
    info = path.lstat()
    return {'dev': info.st_dev, 'ino': info.st_ino, 'uid': info.st_uid,
            'mode': stat.S_IMODE(info.st_mode), 'directory': stat.S_ISDIR(info.st_mode),
            'symlink': stat.S_ISLNK(info.st_mode)}

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def command(argv):
    child = subprocess.run(argv, capture_output=True, timeout=30)
    return {'command': argv, 'exitCode': child.returncode,
            'stdout': child.stdout.decode(errors='replace'), 'stderr': child.stderr.decode(errors='replace')}

def absent(pid):
    try:
        os.kill(pid, 0)
        return 'alive'
    except OSError as error:
        return errno.errorcode.get(error.errno, str(error.errno))

receipt = {'startedAt': stamp(), 'action': 'Read-only ownership audit and complete regular-file backup; no deletion.',
    'root': str(root), 'destination': str(destination), 'repositoryEdited': False,
    'deleted': False, 'knownUnknownRootsTouched': False, 'unknownRoots': ['bvNnrb', 'BjNfGE']}
try:
    original = identity(root)
    receipt['rootIdentity'] = original
    if not original['directory'] or original['symlink'] or original['uid'] != os.getuid():
        raise RuntimeError('Root is not an owned non-symlink directory.')
    records = [json.loads(line) for line in ledger.read_text().splitlines() if line]
    run_owner = json.loads(marker.read_text())
    hosts = [record for record in records if record.get('pid') == 8953 and record.get('pgid') == 8953
        and record.get('runId') == run_id and record.get('cmd') == 'opencode serve ' + str(root / 'workspace')]
    exits = [record for record in records if record.get('pid') == 8953 and record.get('runId') == run_id and record.get('exited') is True]
    if len(hosts) != 1 or len(exits) != 1 or run_owner.get('pid') != 8821 or run_owner.get('runId') != run_id:
        raise RuntimeError('Authoritative Host/root/run-owner ledger mismatch.')
    wrapper = json.loads((base / 'r14-event-observer-e2e.json').read_text())
    if wrapper.get('monitorPid') != 8820 or wrapper.get('signal') is not None or wrapper.get('exitCode') != 1:
        raise RuntimeError('R14 wrapper terminal identity mismatch.')
    receipt['ledgerBinding'] = {'runId': run_id, 'hostPid': 8953, 'hostPgid': 8953,
        'runOwnerPid': 8821, 'monitorPid': 8820, 'command': hosts[0]['cmd'],
        'hostExitedRecord': exits[0], 'runOwnerMarker': run_owner,
        'wrapperToActualToolPidAssociation': 'unknown',
        'reason': 'The R14 wrapper persisted monitor8820 but not owned.started actual pid; ledger marker records owner8821 without parent pid. Adjacent PIDs and times do not establish their edge.'}
    receipt['processes'] = {str(pid): absent(pid) for pid in [8820, -8820, 8821, -8821, 8953, -8953]}
    if any(value != 'ESRCH' for value in receipt['processes'].values()):
        raise RuntimeError('A known PID/PGID is not proven absent.')
    receipt['lsof'] = command(['/usr/sbin/lsof', '-nP', '+D', str(root)])
    if receipt['lsof']['exitCode'] != 1 or receipt['lsof']['stdout'] or receipt['lsof']['stderr']:
        raise RuntimeError('Open file/cwd check is not empty.')
    mounted = command(['/sbin/mount'])
    hdi = subprocess.run(['/usr/bin/hdiutil', 'info', '-plist'], capture_output=True, timeout=30)
    images = plistlib.loads(hdi.stdout).get('images', []) if hdi.returncode == 0 else None
    receipt['mountCheck'] = {'mountExitCode': mounted['exitCode'], 'mountStderr': mounted['stderr'],
        'hdiExitCode': hdi.returncode, 'hdiStderr': hdi.stderr.decode(errors='replace'),
        'matchingMounts': [line for line in mounted['stdout'].splitlines() if str(root) in line],
        'matchingImages': [image for image in (images or []) if str(root) in json.dumps(image)]}
    if mounted['exitCode'] != 0 or mounted['stderr'] or hdi.returncode != 0 or hdi.stderr or images is None or receipt['mountCheck']['matchingMounts'] or receipt['mountCheck']['matchingImages']:
        raise RuntimeError('No-matching-mount check is not proven.')
    files = []
    symlinks = []
    backup = destination / 'wnhzKF'
    backup.mkdir()

    def copy_file(source, dest):
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode):
            raise RuntimeError('Backup member is not a regular non-symlink file: ' + str(source))
        before = digest(source)
        source_identity = identity(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as original, dest.open('xb') as copied:
            shutil.copyfileobj(original, copied)
        if before != digest(source) or before != digest(dest) or identity(source) != source_identity:
            raise RuntimeError('Backup bytes or original identity changed: ' + str(source))
        files.append({'source': str(source), 'backup': str(dest), 'bytes': info.st_size,
                      'sha256': before, 'sourceIdentity': source_identity})

    for directory, directories, filenames in os.walk(root, followlinks=False):
        current = Path(directory)
        for name in list(directories):
            path = current / name
            if path.is_symlink():
                symlinks.append({'path': str(path), 'identity': identity(path), 'target': os.readlink(path)})
                directories.remove(name)
        for name in filenames:
            source = current / name
            if source.is_symlink():
                symlinks.append({'path': str(source), 'identity': identity(source), 'target': os.readlink(source)})
                continue
            copy_file(source, backup / source.relative_to(root))
    for source in [ledger, marker, base / 'r14-event-observer-e2e.json',
                   base / 'r14-event-observer-e2e.log', base / 'r14-event-observer-e2e.console',
                   base / 'run-e2e-preflight.mjs']:
        copy_file(source, destination / 'run-evidence' / source.name)
    if identity(root) != original:
        raise RuntimeError('Root identity changed during backup.')
    for entry in files:
        if digest(Path(entry['source'])) != entry['sha256'] or digest(Path(entry['backup'])) != entry['sha256']:
            raise RuntimeError('Backup final hash recheck failed: ' + entry['source'])
    receipt.update({'files': files, 'symlinksNotTraversed': symlinks, 'backupFiles': len(files),
        'backupBytes': sum(entry['bytes'] for entry in files), 'allSourceAndCopyHashesVerified': True,
        'eligibleForCleanup': False,
        'stoppedReason': 'Monitor8820 to actual run owner8821 association is unknown; no deletion without authoritative identity evidence.'})
except Exception as error:
    receipt.update({'eligibleForCleanup': False, 'stoppedReason': str(error)})
receipt['finishedAt'] = stamp()
with (destination / 'backup-and-ownership-receipt.json').open('x') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({key: receipt.get(key) for key in ['destination', 'backupFiles', 'backupBytes',
    'allSourceAndCopyHashesVerified', 'eligibleForCleanup', 'deleted', 'stoppedReason']}, ensure_ascii=False, indent=2))

# R16 后继只读审计补记

这是旧 readonly-diff-review.md 的时点补记，不重写旧调查原件。

- same-model 旧整 Session discovery 已由 Requested/Bound、source/target assistant、原 physical Root 的共同 helper 接替；四段重复 registry/parser/discovery 已删，toolNameOfCall 仍服务协议验证。gen357 正式反例及 gen358 green 均归档。
- protocol 对真实 Replica 投影保生产 parser/classifier 的参数所有权；完整 SSE source batch 排除受控取消响应。gen359 两个正式失败与 gen360 green 均保留，不以对响应脚本的预测冒充实际已写内容。
- 实际 r16-root-protocol-e2e 的两 Bound、Replica[1,2]及原 Root owner[3,4]已在真实 Host 日志出现；随后 MCP fixture 工具缺失断言失败。same-model/purpose/capacity 后续 custom 没有执行，不能从先前正式 fixture 的输出推断真实 Host 通过。
- 没有审计或执行最终干净输入全项目 release，没有新 SHA CI 收据。MCP 的 compiler setup 原因仍由主线调查，本归档不提前定因或授绿。
- wnhzKF 已有完整 regular-file 副本及 SHA 收据，但 monitor 到 actual owner 的权威 started edge 缺失；保留原目录，不把进程不存在误写成清理身份已证明。

本次只写 TMP 文档、复制已封口材料并压缩；不改源码、不运行测试/构建、不提交、不清理任何原 scratch。

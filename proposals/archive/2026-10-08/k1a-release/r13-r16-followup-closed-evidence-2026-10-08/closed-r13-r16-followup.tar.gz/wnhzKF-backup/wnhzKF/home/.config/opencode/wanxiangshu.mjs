import { appendFileSync } from 'node:fs'

const candidates = ['test/test-model', 'opencode/test-model', 'backup/test-model']
const failed = new Set()
const providerOf = (model) => model.slice(0, model.indexOf('/'))
export const markProviderFailed = (provider) => failed.add(provider)
export const routingProtocol = 2
export const hasTheoreticalCapacity = (role, purpose) => true

// DELEGATE 9.2 / WHAT[014]: Predictor 与 owner 配成相同模型是合法状态。这个世界
// 故意让 readonly-delegate 分支与角色池分支返回同一个 model：purpose 分流的逻辑
// 证明在 execution-model-routing 单元层（EMR 020/002），世界层不重复证明
// "两池分离"，改证同模型不关闭委托。manager 分支保留候选轮换，provider-fallback
// 腿仍能观察降级路径。
const sharedModel = 'test/test-model-b'

// DELEGATE 9.2 (C): 每次真实路由决策 (role + purpose -> model) 记录到本配置文件
// 同目录的决策日志。provider wire 上不出现 purpose，这个日志是"同伴目标确实由
// readonly-delegate 用途路由而来"的直接见证。写失败不影响调度（purpose 参数
// 本身已由单元缝证明）；日志缺失由 oracle fail-closed。
const decisionsPath = new URL('./wanxiangshu-routing-decisions.jsonl', import.meta.url)
const recordRoutingDecision = (role, purpose, model) => {
  try {
    appendFileSync(decisionsPath, `${JSON.stringify({ role, purpose, model })}\n`)
  } catch {
    // best-effort test scaffolding: scheduling must never depend on a log
  }
}

export default function route(role, running, previous, purpose) {
  if (!new Set(['manager', 'orchestrator', 'engineer', 'devops', 'blogger', 'bookkeeper', 'predictor']).has(role)) {
    throw new Error('unexpected managed role: ' + role)
  }

  let target
  if (purpose === 'readonly-delegate') {
    // The Predictor pool; configured equal to the role-pool model on purpose.
    target = { model: sharedModel, reasoning: 'none' }
  } else if (role === 'manager') {
    if (previous != null && !failed.has(providerOf(previous.model))) {
      target = previous
    } else {
      const model = candidates.find((candidate) => !failed.has(providerOf(candidate)))
      target = { model: model ?? candidates.at(-1), reasoning: 'none' }
    }
  } else {
    target = previous ?? { model: sharedModel, reasoning: 'none' }
  }

  recordRoutingDecision(role, purpose, target.model)
  return target
}

// DELEGATE 14.5: this scheduler runs inside the spawned OpenCode process,
// so the in-process __wanxiangshu_test_predictor_state switch that the
// same-process suites flip is unreachable here; the delegation world declares
// the Predictor slot configured directly. Configuration presence IS the
// enablement (spec WHAT[014]) — no second switch exists to flip.
export const predictorConfiguration = () => ({ state: 'configured', reason: null })

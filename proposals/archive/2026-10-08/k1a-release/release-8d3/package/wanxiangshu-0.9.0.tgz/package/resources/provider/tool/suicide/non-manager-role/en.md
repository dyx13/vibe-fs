suicide is Manager-only

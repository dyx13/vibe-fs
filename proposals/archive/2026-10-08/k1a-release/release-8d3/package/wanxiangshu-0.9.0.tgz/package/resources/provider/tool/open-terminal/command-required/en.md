command is required

The information to route.

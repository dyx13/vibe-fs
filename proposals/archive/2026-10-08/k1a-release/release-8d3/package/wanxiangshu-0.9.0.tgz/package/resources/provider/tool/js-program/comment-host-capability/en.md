Host capability

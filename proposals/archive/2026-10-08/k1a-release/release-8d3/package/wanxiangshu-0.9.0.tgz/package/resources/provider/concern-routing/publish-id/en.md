The live concern address.

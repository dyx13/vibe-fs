anchor RegExp is invalid

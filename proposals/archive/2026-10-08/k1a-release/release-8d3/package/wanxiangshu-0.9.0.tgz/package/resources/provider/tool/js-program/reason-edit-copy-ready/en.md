Copy-ready corrected change:

mv: {{source}} -> {{destination}}: {{error}}

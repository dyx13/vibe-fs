The charge was integrated.

A charge is required.

The wait was cancelled.

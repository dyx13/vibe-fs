# R19 Host title 与受管 user 复用边界

本收据只记录本轮局部正式红、生产修复范围及待验边界。生产绿、真实 Host title HTTP 和最终 release 结果由后续输入分别登记。

## 实际 E2E

`r18-retirement-owner-e2e.log` 为 34 pass / 1 fail / 0 skip / 0 TODO，唯一最终失败为 `humanroot-manager-title.0`、`title.0` 两个 required 分支未到达。外层 `r18-retirement-owner-e2e.json` duration 19680.935458ms、exit 1、inputsEqual true；根代理记录内层 E2E 为18.244s，二者不可混写。

精确 scratch 为 `/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/oc-e2e-l1vkqA`。`xdg/data/opencode/log/opencode.log` 第17、55、113、152行均有 `small=true agent=title` 的 stream 记录。第113、152行对应 HumanRoot 和主 orchestrator。只读 SQLite 中四个 root session 的 title 均仍为 `New session - ...`。Strength 两个 title 现为 optional，因此终局没有列出它们，不能认为它们已到达。

Host 的 stream 日志发生在请求准备之前，不能当成 HTTP 已发送证据。本轮没有留存 provider.requests 全数组，未取得原始 title HTTP body；mock 未报告 unexpected、fatal 与分类失败，故不能以未知 wire 形状修改 matcher。

## 根因及公开边界

本地 Host 源 `packages/opencode/src/session/prompt.ts:228` 的 title 调用明确把 `firstInfo` 原 User 作为 `llm.stream.user`，独立 `agent=title`、小模型、空工具；`session/llm/request.ts:119` 的公开 `chat.params` 参数明确 `message: input.user`、`agent: input.agent.name`。`session/llm.ts:86` 先记录 stream，随后 prepare 才调用 hook。`prompt.ts:1134` 将 title task 交 `Effect.ignore`，title 准备失败不终止正常工作。源 checkout 不是安装二进制等价性证明；真实安装 Host1.18.29 的 runtime 日志和正式同形 public hook 反例共同支持此因果，后续实际 E2E 仍须证明 required title HTTP 闭环。

`ChatParamsHook.validateManagedObservation` 只凭 exact User key 读取原 execution 的 admission，随后比较 participant 与当前 request agent，把独立 Host title 当成原工作中的 `engineer -> title` 身份漂移。原注释声称 title 没有 Accepted，与 Host 复用原 User 的实际前提不符。原033辅助正例只用了无 Accepted、无 lease 的新 key，未覆盖此情形。

## 正式红与夹具前提修正

1. `r19-host-title-same-user-red.log` 是首次 native 诊断：0 pass / 2 fail / 0 cancelled / 0 skip / 0 TODO，1244.295791ms。第一叶证明真实 `PROMPT-006 ... (engineer -> title)`；第二叶由测试将 F# `OpencodeModel` 用 structuredClone 丢失 prototype 后与原对象 deepStrictEqual，属于新增夹具前提错误，不是产品失败。原日志保留。
2. 手工改为比较前后 structuredClone 的数据，并额外断言 User、User.model 与请求 catalog model 原对象引用不变。
3. 原环境 `node scripts/build.mjs` 成功，generation371。无 F# 生产修改时刷新新增 JS 测试输入。
4. 正式命令：先 source `/private/tmp/vibe-fs-release-env-oct8-7eQsBo/env.sh`，再 export `WXS_VERIFICATION_NUGET_PROJECT_TREE_ID=$(git rev-parse 'HEAD^{tree}')`，运行 `node --test --test-name-pattern='Host title observes|title exemption does not' requirements/host-boundary/tests/033.test.mjs`。原件 `r19-host-title-same-user-formal-red.log`：exit1，1 pass / 1 fail / 0 cancelled / 0 skip / 0 TODO，974.828125ms。唯一失败仍为 `engineer -> title`。第二个正式 case 的5项模型、managed participant、unknown agent、Title 与 title-other 漂移均被拒绝，input/output、capacity、durable projection 保持不变。

## 修复与剩余边界

只修改033测试、`ChatParamsHook.fs`、WHAT033。生产仅明确 top-level primitive `agent === 'title'` 的 Host 请求不进入 managed lease 校验/温度投影；不按 unknown Role、文本、trim/casefold 或 session-current 猜测，不新增 registry/type/lease。WHAT澄清 title 可复用受管 User，却不执行该 managed work；其模型和参数独立，普通 managed 漂移仍拒绝。

完成本收据时生产修改后尚未构建/测试，generation371不再是当前生产输入的新鲜证明。根代理将统一构建并跑033/相关套件/真实E2E。033 title 正例在绿后必须证明两次调用均不改 User/模型/输出、capacity、durable projection、scheduler调用数量，无 abort/send。真实E2E两 required title 分支保持 required，不能改 optional、删除或用内部广匹配取代。

未扩大到 summary/compaction 及任意未知辅助 agent；未授予完整 Host 或全项目验收。未执行新重型调查、未杀/删本次 scratch、未提交。

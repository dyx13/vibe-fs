# Integration final reconciliation

Frozen 8d0c8ab2e6049a14944bdd2c2dcc5464c29d2aa4, actual generation373, before/after inputs and tools equal. Wrapper314069.732ms, exit1.

Repository suites: original300000ms boundary;43/44drained,016active,0queued. All four verdict counts unknown. 016 was admitted at279526.608ms with20473.392ms remaining. Its first readonly body passed; second paused Node body began before cutoff. The other four physical bodies and ordinary remainder did not execute in this file.

Durable022 completed240785.489ms own-worker wall; structured012 completed56095.688ms. Slot occupancy284436.730ms and299942.269ms. These logs prove long real work plus late admission; they do not prove reordering alone fits the full scope.

Distribution1/1file:3pass0fail0skip1TODO, exits1pending-proof. Harness292/292cases:291pass1fail0skip0TODO,12.6s; actual lower-bound deadline assertion observed999ms. Preserve this failure before any controlled-clock regression/fix.

Root group27579 cleanup accepted16.748ms; wrapper monitor27575ESRCH; all46 exact recorded worker/runner PID observationsESRCH. Quiet logs have no per-tool monitor records and no exact filesystem/mount owner path, so those scopes remain unknown. No cleanup was attempted by this audit.

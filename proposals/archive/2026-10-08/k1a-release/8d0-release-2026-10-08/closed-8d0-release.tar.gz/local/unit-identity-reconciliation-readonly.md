# Unit final reconciliation

Frozen commit `8d0c8ab2e6049a14944bdd2c2dcc5464c29d2aa4`, tree `a0fd75c9676ff12f8a6c5d75d007c9bd1dd7d8ea`; digest `fab558de8ae6ebabe44dea481dc81ee3600f472fc483bf1c003341cd2904e1c7`, 4674 inputs, clean before/after. Actual clean build generation 373; generation 372 was only the pre-unified snapshot.

824/824 drained with no active or queued files. 4970 pass, 0 fail, 127 skip, 388 TODO; exit 1 is pending-proof policy. Original 300000ms budget was not reached.

822 valid own-worker cost observations total 530793.883ms concurrent wall, 318042663us CPU; these are not stage elapsed time and exclude child tools. Two invalid observations at unit.log:753 and :1524 name foreign nested workers. Their CPU/wall remains unknown. Both files passed; invalid cost must not be mistaken for a product verdict failure.

016 admitted at 12475.487ms and drained at 170223.879ms. Its valid native worker interval is 157713.182ms, CPU 41006555us.

Root group 70530 accepted cleanup in 16.618ms. All 203 owned monitor lifecycles close; all 1232 exact recorded PIDs were ESRCH when sampled. This establishes these owned process identities only, without a global filesystem/mount assertion.

The prior ddb run remains failed at 556/824 and unresolved. One current complete run does not prove that old throughput cause was fixed. Different commits prevent attributing old/new CPU differences to environment alone.

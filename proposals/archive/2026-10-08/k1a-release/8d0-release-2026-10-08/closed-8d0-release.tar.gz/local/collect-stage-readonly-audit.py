from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import os
import re
import statistics
import subprocess
import sys

ROOT = Path('/Users/yuanxi/Workwork/vibe-fs')
BASE = Path('/private/tmp/vibe-fs-oct8-release-8d0c8ab2e604')
EXPECTED_COMMIT = '8d0c8ab2e6049a14944bdd2c2dcc5464c29d2aa4'
EXPECTED_TREE = 'a0fd75c9676ff12f8a6c5d75d007c9bd1dd7d8ea'
freeze = json.loads((BASE / 'frozen-input.json').read_text())
if (freeze['commit'], freeze['tree']) != (EXPECTED_COMMIT, EXPECTED_TREE):
    raise SystemExit('Frozen input identity mismatch')

stage = sys.argv[1]
log = Path(sys.argv[2]).resolve()
prefix = {'unit': 'runner', 'integration': 'integration:suites'}[stage]
plan_file = BASE / (stage + '-planned-files.json')
planned_files = json.loads(plan_file.read_text())
lines = log.read_text().splitlines()
parsed = {key: [] for key in ['lifecycle', 'cost', 'test', 'tool', 'nativeCost']}
markers = [
    (prefix + ': file lifecycle ', 'lifecycle'),
    (prefix + ': worker cost ', 'cost'),
    ('[verification-test-start] ', 'test'),
    ('[verification-tool-phase] ', 'tool'),
    ('[verification-worker-cost] ', 'nativeCost'),
]
for number, line in enumerate(lines, 1):
    for marker, key in markers:
        if line.startswith(marker):
            try:
                parsed[key].append({'line': number, **json.loads(line[len(marker):])})
            except json.JSONDecodeError:
                pass

first = next(event for event in parsed['lifecycle'] if event['type'] == 'runner:file-start')
inner, outer = first['pid'], first['parentPid']
starts = [event for event in parsed['lifecycle'] if event['type'] == 'runner:file-start' and event.get('pid') == inner]
by_file = {event['entryFile']: event for event in starts}
if len(by_file) != len(starts) or not set(by_file).issubset(planned_files):
    raise SystemExit('Unexpected top-level admission identity')
drains = [event for event in parsed['lifecycle'] if event['type'] == 'runner:file-drained' and event['entryFile'] in by_file]
drained = {event['entryFile'] for event in drains}
cleanup = [
    {'line': number, 'text': line}
    for number, line in enumerate(lines, 1)
    if line.startswith(f'{prefix}: post-exit group verification/reclamation: pid={inner};')
]
if not cleanup:
    raise SystemExit('No terminal root group cleanup receipt; stage still running or cleanup unknown')
terminal_pattern = re.compile(re.escape(prefix) + r': (?:\d+ passed, \d+ failed|verdict counts unavailable; no authoritative summary); (\d+)/(\d+) planned file\(s\) completed')
terminal = next((
    {'line': number, 'text': line, 'completed': int(match[1]), 'planned': int(match[2])}
    for number, line in enumerate(lines, 1)
    if number > cleanup[-1]['line'] and (match := terminal_pattern.fullmatch(line))
), None)
if not terminal or terminal['planned'] != len(planned_files):
    raise SystemExit('No matching terminal summary for complete planned manifest')

counts = dict(passed='unknown', failed='unknown', skipped='unknown', todo='unknown')
authority = 'verdict counts unavailable' not in terminal['text']
compact = [
    {'line': number, 'text': line}
    for number, line in enumerate(lines, 1)
    if re.match(rf'^\[test-summary\] {len(planned_files)} file\(s\), ', line)
]
if authority:
    counts['passed'], counts['failed'] = map(int, re.search(r': (\d+) passed, (\d+) failed;', terminal['text']).groups())
    partial = next((line for line in lines[terminal['line']:] if line.startswith(prefix + ': partial evidence; ')), None)
    counts['skipped'], counts['todo'] = map(int, re.search(r'(\d+) skipped, (\d+) TODO', partial).groups()) if partial else (0, 0)
    if compact:
        expected = {
            key: int(match[1]) if (match := re.search(rf'(\d+) {word}', compact[-1]['text'])) else 0
            for key, word in [('passed', 'passed'), ('failed', 'failed'), ('skipped', 'skipped'), ('todo', 'todo')]
        }
        if expected != counts:
            raise SystemExit('Compact and authoritative supervisor counts disagree')

costs = {}
for cost in parsed['cost']:
    if cost['entryFile'] in by_file and (cost.get('preImport') or {}).get('parentPid') == inner:
        costs[cost['entryFile']] = cost
valid = [cost for cost in costs.values() if cost.get('status') == 'complete' and cost.get('interval')]
backstop = [{'line': number, 'text': line} for number, line in enumerate(lines, 1) if line == f'{prefix}: suite exceeded the 300000ms physical backstop']
horizon = 300000 if backstop else max(event['elapsedMs'] for event in drains)
active = {}
lanes = [[], []]
for event in parsed['lifecycle']:
    file = event['entryFile']
    if event['type'] == 'runner:file-start' and event.get('pid') == inner:
        free = [lane for lane in range(2) if lane not in {item['lane'] for item in active.values()}]
        if not free:
            raise SystemExit('Lifecycle exceeds frozen concurrency2')
        item = {'entryFile': file, 'lane': free[0], 'startLine': event['line'], 'startMs': event['elapsedMs'], 'endLine': None, 'endMs': None}
        lanes[free[0]].append(item)
        active[file] = item
    elif event['type'] == 'runner:file-drained' and file in active:
        item = active.pop(file)
        item.update(endLine=event['line'], endMs=event['elapsedMs'])
for lane in lanes:
    for item in lane:
        item['observedOccupancyMs'] = max(0, min(item['endMs'] if item['endMs'] is not None else horizon, horizon) - item['startMs'])
lane_totals = [{
    'lane': index, 'admitted': len(lane), 'drained': sum(item['endMs'] is not None for item in lane),
    'occupancyMs': sum(item['observedOccupancyMs'] for item in lane),
    'unoccupiedOrHandoffMs': horizon - sum(item['observedOccupancyMs'] for item in lane),
} for index, lane in enumerate(lanes)]

workers = {event['pid'] for event in parsed['test'] + parsed['nativeCost'] if event.get('parentPid') == inner}
workers.update(cost['pid'] for cost in costs.values() if cost.get('pid'))
spawns = [event for event in parsed['tool'] if event['phase'] == 'monitor-spawned' and event.get('pid') in workers and event.get('parentPid') == inner]
monitors = []
known_pids = {inner, outer} | workers
for spawn in spawns:
    monitor = spawn['monitorPid']
    events = [event for event in parsed['tool'] if (event.get('monitorPid') == monitor and event.get('pid') == spawn['pid']) or (event.get('pid') == monitor and event.get('parentPid') == spawn['pid'])]
    phases = sorted({event['phase'] for event in events})
    known_pids.add(monitor)
    known_pids.update(event['toolPid'] for event in events if event.get('toolPid'))
    monitors.append({
        'monitorPid': monitor, 'workerPid': spawn['pid'], 'phases': phases,
        'complete': all(phase in phases for phase in ['monitor-spawned', 'tool-spawned', 'tool-exited', 'group-drained', 'monitor-closed']),
        'events': events,
    })
pid_observations = []
for pid in sorted(known_pids):
    try:
        os.kill(pid, 0)
        state = 'present; exact lifetime may have ended and PID may be reused'
    except ProcessLookupError:
        state = 'ESRCH'
    except PermissionError:
        state = 'EPERM; unknown ownership'
    pid_observations.append({'pid': pid, 'observation': state})

comparison = None
if stage == 'unit':
    old = json.loads(Path('/private/tmp/vibe-fs-oct8-final-release/unit-ddb-readonly-audit.json').read_text())
    old_costs = {cost['entryFile']: cost for cost in old['validCompleteWorkerCosts']}
    matched = [{'entryFile': cost['entryFile'], 'old': old_costs[cost['entryFile']]['interval'], 'new': cost['interval']} for cost in valid if cost['entryFile'] in old_costs]
    comparison = {
        'baselineCommit': old['input']['commit'], 'baselineLog': old['log'], 'matchedFiles': len(matched),
        'oldWallMs': sum(item['old']['wallMs'] for item in matched),
        'newWallMs': sum(item['new']['wallMs'] for item in matched),
        'oldCpuMicros': sum(item['old']['cpuUserMicros'] + item['old']['cpuSystemMicros'] for item in matched),
        'newCpuMicros': sum(item['new']['cpuUserMicros'] + item['new']['cpuSystemMicros'] for item in matched),
        'medianWallRatio': statistics.median(item['new']['wallMs'] / item['old']['wallMs'] for item in matched if item['old']['wallMs'] > 0) if matched else None,
        'largestWallDeltas': sorted(matched, key=lambda item: item['new']['wallMs'] - item['old']['wallMs'], reverse=True)[:20],
        'limitation': 'Different frozen commits and production inputs: matched filenames do not prove equal semantic work or environment. Own-worker CPU excludes child tools; concurrent wall sums are not elapsed duration.',
    }

current_identity = {name: subprocess.check_output(command, cwd=ROOT, text=True).strip() for name, command in {
    'commit': ['git', 'rev-parse', 'HEAD'], 'tree': ['git', 'rev-parse', 'HEAD^{tree}'], 'status': ['git', 'status', '--porcelain=v1'],
}.items()}
result = {
    'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stage': stage, 'frozenInput': {key: value for key, value in freeze.items() if key != 'inputs'},
    'currentIdentity': current_identity, 'log': str(log), 'logSha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    'innerPid': inner, 'outerPid': outer, 'budget': {'suitePhysicalBackstopMs': 300000, 'fileConcurrency': 2, 'withinFileConcurrency': 1},
    'plannedFiles': planned_files, 'admittedFiles': len(starts), 'drainedFiles': len(drains),
    'activeFiles': [file for file in by_file if file not in drained], 'queuedFiles': [file for file in planned_files if file not in by_file],
    'counts': counts, 'authoritativeSummary': authority, 'terminal': terminal, 'compactSummary': compact,
    'backstop': backstop, 'rootGroupCleanup': cleanup,
    'laneHorizonMs': horizon, 'laneHorizonMeaning': 'Original physical backstop on timeout; otherwise last observed drain. Slot occupancy is not CPU utilization.',
    'lanes': lanes, 'laneTotals': lane_totals, 'firstAdmissions': starts[:2],
    'lastNativeOwnedTestStarts': [event for event in parsed['test'] if event.get('parentPid') == inner][-15:],
    'validCompleteCosts': valid, 'costStatusCounts': dict(Counter(cost['status'] for cost in costs.values())),
    'missingCostFiles': [file for file in by_file if file not in costs],
    'workerCostTotals': {'files': len(valid), 'wallMs': sum(cost['interval']['wallMs'] for cost in valid), 'cpuUserMicros': sum(cost['interval']['cpuUserMicros'] for cost in valid), 'cpuSystemMicros': sum(cost['interval']['cpuSystemMicros'] for cost in valid)},
    'workerNonzeroExits': [cost for cost in valid if cost['exit']['exitCode'] != 0],
    'ownedToolClosure': {'monitorSpawns': len(monitors), 'completeMonitors': sum(item['complete'] for item in monitors), 'incompleteMonitors': [item for item in monitors if not item['complete']]},
    'ownedMonitors': monitors, 'exactKnownPidObservations': pid_observations, 'ddbComparison': comparison,
    'limitations': ['No new tests/builds/code edits or broad cleanup executed.', 'Nested fixture failure text is not counted as an ordinary failure; final counts require the native root summary.', 'ESRCH is current absence evidence; a present PID alone does not establish continued ownership.', 'Group cleanup does not prove filesystem or read-only mount cleanup.', 'Wrapper final input digest/build manifest and exit result require separate final receipts.'],
}
output = BASE / (stage + '-readonly-audit.json')
with output.open('x') as file:
    json.dump(result, file, ensure_ascii=False, indent=2)
    file.write('\n')
summary = {key: result[key] for key in ['capturedAt', 'stage', 'currentIdentity', 'log', 'logSha256', 'innerPid', 'outerPid', 'admittedFiles', 'drainedFiles', 'activeFiles', 'counts', 'authoritativeSummary', 'terminal', 'backstop', 'rootGroupCleanup', 'laneHorizonMs', 'laneTotals', 'costStatusCounts', 'missingCostFiles', 'workerCostTotals', 'workerNonzeroExits', 'ownedToolClosure']}
summary['plannedCount'] = len(planned_files)
summary['queuedCount'] = len(result['queuedFiles'])
summary['exactKnownPidCount'] = len(pid_observations)
summary['presentOrUnknownPids'] = [item for item in pid_observations if item['observation'] != 'ESRCH']
(BASE / (stage + '-readonly-audit.txt')).write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))

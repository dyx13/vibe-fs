import fs from 'node:fs'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { assertBuildFresh, collectVerificationInputs, computeDigest } from '/Users/yuanxi/Workwork/vibe-fs/scripts/lib/build-state.mjs'
import { spawnOwnedVerificationTool } from '/Users/yuanxi/Workwork/vibe-fs/scripts/lib/verification-owned-tool.mjs'
import { superviseNodeTest } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/e2e/support/supervise-node-test.mjs'
import { PROJECT_CHECK_TIMEOUT_MS, SUITE_BACKSTOP_MS, WATCHDOG_TIMEOUT_MS } from '/Users/yuanxi/Workwork/vibe-fs/requirements/verification-system/tests/e2e/support/time-budget.js'

const root = '/Users/yuanxi/Workwork/vibe-fs'
const directory = '/private/tmp/vibe-fs-oct8-final-release'
const file = `${root}/requirements/verification-system/tests/016.test.mjs`
const frozen = JSON.parse(fs.readFileSync(`${directory}/frozen-input.json`, 'utf8'))
const manifestPath = `${root}/.fable-build/build-manifest.json`
const expectedCommit = 'ddb0c28cfbfa35762b2115f9609c85a296d68d1a'
const expectedDigest = 'fb36b4e2f95ad89f1534c15f077e497a82b6470a0becc782785b57e03adc3633'
if (frozen.commit !== expectedCommit || frozen.digest !== expectedDigest) throw new Error('Unexpected frozen input authority')
if (SUITE_BACKSTOP_MS !== 300000 || PROJECT_CHECK_TIMEOUT_MS !== 180000) throw new Error('Original integration budgets differ')

if (process.argv[2] === '--owned-full016') {
  await superviseNodeTest({
    files: [file], label: 'supplemental/full016', logPrefix: 'full016',
    silenceMs: Math.max(WATCHDOG_TIMEOUT_MS, PROJECT_CHECK_TIMEOUT_MS + 5000),
    env: process.env, throwOnFailure: true,
  })
} else {
  if (process.argv.length !== 2) throw new Error('No file selection or Node test flags are accepted')
  const receiptPath = `${directory}/supplemental-full016.json`
  const logPath = `${directory}/supplemental-full016.log`
  const receiptFd = fs.openSync(receiptPath, 'wx', 0o600)
  let logFd
  let owned
  let loggingFailure = null
  const startedAt = new Date().toISOString()
  const start = performance.now()
  const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()
  const snapshot = () => {
    assertBuildFresh({ root })
    const manifestBytes = fs.readFileSync(manifestPath)
    const manifest = JSON.parse(manifestBytes)
    return {
      commit: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'),
      status: git('status', '--porcelain'), digest: computeDigest(collectVerificationInputs(root)),
      build: { generation: manifest.generation, compilerInputDigest: manifest.compiler.inputDigest,
        manifestSha256: createHash('sha256').update(manifestBytes).digest('hex') },
    }
  }
  const observe = pid => {
    if (!Number.isInteger(pid)) return 'not-started'
    try { process.kill(pid, 0); return 'still-running' } catch (error) { return error.code }
  }
  const receipt = {
    kind: 'Finite supplemental complete016 file; does not replace the failed full integration stage',
    completeIntegrationStage: false, plannedFiles: [file], nodeTestNamePattern: null, nodeWholeFileTimeout: null,
    frozenReceipt: `${directory}/frozen-input.json`, startedAt,
    physicalBackstopMs: SUITE_BACKSTOP_MS, perTestTimeoutEnvMs: PROJECT_CHECK_TIMEOUT_MS,
    verdictSilenceMs: Math.max(WATCHDOG_TIMEOUT_MS, PROJECT_CHECK_TIMEOUT_MS + 5000),
    command: [process.execPath, fileURLToPath(import.meta.url), '--owned-full016'],
    log: logPath, counts: { pass: 'unknown', fail: 'unknown', skip: 'unknown', TODO: 'unknown' },
  }
  try {
    logFd = fs.openSync(logPath, 'wx', 0o600)
    receipt.before = snapshot()
    if (receipt.before.commit !== expectedCommit || receipt.before.tree !== frozen.tree ||
        receipt.before.status !== '' || receipt.before.digest !== expectedDigest ||
        receipt.before.build.generation !== 342 || process.version !== frozen.node ||
        process.env.NODE_TEST_CONCURRENCY !== '2' || process.env.UNIT_VERDICT_SILENCE_MS !== '30000' ||
        process.env.WXS_VERIFICATION_NUGET_PROJECT_TREE_ID !== frozen.tree) {
      throw new Error('The frozen generation342 input or original runtime environment is not current')
    }
    const env = { ...process.env, WXS_RELEASE: '1', WXS_TIER_INTEGRATION: '1',
      PER_TEST_TIMEOUT_MS: String(PROJECT_CHECK_TIMEOUT_MS) }
    for (const name of ['TESTS_MJS_FILES', 'NODE_TEST_CONTEXT', 'WXS_TIER_RELEASE']) delete env[name]
    receipt.environment = Object.fromEntries(['NODE_TEST_CONCURRENCY', 'UNIT_VERDICT_SILENCE_MS', 'WXS_RELEASE',
      'WXS_TIER_INTEGRATION', 'PER_TEST_TIMEOUT_MS', 'WXS_VERIFICATION_NUGET_PROJECT_TREE_ID'].map(name => [name, env[name]]))
    receipt.toolDispatchedAt = new Date().toISOString()
    const toolStart = performance.now()
    owned = spawnOwnedVerificationTool(process.execPath, receipt.command.slice(1), { cwd: root, env })
    receipt.monitorPid = owned.child.pid
    for (const stream of [owned.child.stdout, owned.child.stderr]) stream.on('data', chunk => {
      try { fs.writeSync(logFd, chunk) } catch (error) { loggingFailure ??= error; owned.stop() }
    })
    const started = await owned.started
    receipt.started = { pid: started.pid, failure: started.failure === null ? null : String(started.failure.stack ?? started.failure) }
    receipt.toolStartedObservedAt = new Date().toISOString()
    const result = await owned.completed
    receipt.toolActiveClockMs = performance.now() - toolStart
    receipt.toolTerminalObservedAt = new Date().toISOString()
    receipt.result = { exitCode: result.exitCode, signal: result.signal,
      failure: result.failure === null ? null : String(result.failure.stack ?? result.failure) }
    receipt.monitorObservation = observe(owned.child.pid)
    receipt.actualToolObservation = observe(receipt.started.pid)
    receipt.after = snapshot()
    receipt.inputsEqual = receipt.before.commit === receipt.after.commit && receipt.before.tree === receipt.after.tree &&
      receipt.before.status === receipt.after.status && receipt.before.digest === receipt.after.digest &&
      receipt.before.build.manifestSha256 === receipt.after.build.manifestSha256
  } catch (error) {
    receipt.wrapperFailure = String(error.stack ?? error)
    if (owned) { owned.stop(); await owned.completed }
  } finally {
    if (logFd !== undefined) fs.closeSync(logFd)
    receipt.wrapperActiveClockMs = performance.now() - start
    receipt.finishedAt = new Date().toISOString()
    receipt.wrapperWallMs = Date.parse(receipt.finishedAt) - Date.parse(startedAt)
    receipt.loggingFailure = loggingFailure === null ? null : String(loggingFailure.stack ?? loggingFailure)
    if (fs.existsSync(logPath)) {
      const log = fs.readFileSync(logPath)
      receipt.logSha256 = createHash('sha256').update(log).digest('hex')
      receipt.innerCleanupLines = log.toString('utf8').split('\n').filter(line => line.startsWith('full016: ') &&
        /post-exit group|residual process group|process group .*reclaimed|file streams:|queued file|physical backstop|verdict counts unavailable/.test(line))
      const summary = /full016: (\d+) passed, (\d+) failed; (\d+)\/(\d+) planned file\(s\) completed/.exec(log.toString('utf8'))
      const exclusions = /full016: partial evidence; (\d+) skipped, (\d+) TODO/.exec(log.toString('utf8'))
      if (summary) {
        receipt.completedFiles = Number(summary[3])
        receipt.counts.pass = Number(summary[1]); receipt.counts.fail = Number(summary[2])
        receipt.counts.skip = exclusions ? Number(exclusions[1]) : 0
        receipt.counts.TODO = exclusions ? Number(exclusions[2]) : 0
      }
    }
    receipt.cleanupScope = 'Existing supervisor owns its isolated HOME and inner group; owned-tool completion and exact monitor/tool PID observations are recorded. No claim of exhaustive fixture directory or mount cleanup.'
    receipt.accepted = receipt.result?.exitCode === 0 && receipt.result?.signal === null && receipt.result?.failure === null &&
      receipt.inputsEqual === true && receipt.monitorObservation === 'ESRCH' && receipt.actualToolObservation === 'ESRCH' &&
      receipt.loggingFailure === null && receipt.wrapperFailure === undefined
    fs.writeSync(receiptFd, JSON.stringify(receipt, null, 2) + '\n')
    fs.closeSync(receiptFd)
    process.stdout.write(JSON.stringify(receipt, null, 2) + '\n')
    process.exitCode = receipt.accepted ? 0 : 1
  }
}

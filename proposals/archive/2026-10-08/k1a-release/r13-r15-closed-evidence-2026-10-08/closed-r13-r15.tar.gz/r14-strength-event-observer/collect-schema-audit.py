import pathlib,json,hashlib,shutil,collections
base=pathlib.Path('/private/tmp/vibe-fs-oct8-alias-release')
out=base/'r14-strength-event-observer'
tmp=pathlib.Path('/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T')
repo=pathlib.Path('/Users/yuanxi/Workwork/vibe-fs')
audit={'schema':'r14-actual-strength-observer-audit-v1','scope':'Read-only closed-run facts; TMP patches only; no test/build/source edits','runs':[]}
for name in ['oc-e2e-2KQUIa','oc-e2e-5z0lRH']:
 d=out/name;d.mkdir()
 work=tmp/name/'workspace';events=[];provenance=[]
 for file in sorted((work/'.git/wanxiang/events').glob('*.ndjson')):
  raw=file.read_bytes();provenance.append({'path':str(file),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  for line,text in enumerate(raw.decode().splitlines(),1):
   event=json.loads(text)
   if event.get('stream_id','').startswith('strength/'):
    events.append({'sourceFile':str(file),'sourceLine':line,'event':event})
 (d/'actual-strength-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
 refs=sorted(set(ref for row in events for ref in row['event'].get('payload_refs',[])))
 payloads=[]
 for ref in refs:
  src=work/'.git/wanxiang/payloads'/ref;raw=src.read_bytes();assert hashlib.sha256(raw).hexdigest()==ref
  dst=d/(ref+'.payload.json');dst.write_bytes(raw)
  payloads.append({'sourcePath':str(src),'copy':str(dst),'bytes':len(raw),'sha256':ref})
 summary={'scratch':str(tmp/name),'provenance':provenance,'eventTypes':dict(collections.Counter(row['event']['event_type'] for row in events)),
  'bindings':[row for row in events if row['event']['event_type']=='DelegationBound'],'payloads':payloads}
 audit['runs'].append(summary)
for file in [base/'r13-stopped-transform-e2e.log',base/'r13-stopped-transform-e2e.json']:
 shutil.copyfile(file,out/file.name)
sourceFiles=['requirements/verification-system/tests/e2e/support/journal-observer.js','requirements/verification-system/tests/e2e/support/long-stroke-oracles.mjs','src/Wanxiangshu/Strength/Persistence/Store.fs']
audit['sourceProvenance']=[{'path':str(repo/f),'sha256':hashlib.sha256((repo/f).read_bytes()).hexdigest()} for f in sourceFiles]
audit['conclusion']='Event type remains DelegationBound and canonical payload is snake_case replica_session_id. factPayloads only walks envelope.Fact and drops raw top-level Strength EventStore envelopes, whereas countFactCase workDir and extractFactCasesAndIdentities already include event_type/payload. New 2KQUIa actual run has exactly two Bound; earlier 5z0lRH has exactly one, so do not cite it as two.'
audit['minimalFix']='Reuse extractFactCasesAndIdentities(envelope,event).cases in factPayloads for both nested JournalEnvelope and top-level EventStore event types; all Long Stroke oracle assertions unchanged.'
audit['formalRegression']='Real Strength Surface durability writes two complete chains with PublishPrepared payload publication; actual NDJSON observer reads 2 Bound; exact payload identities/digests and original requested budgets survive closing and reopening same Store.'
(out/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
(out/'audit.txt').write_text(audit['conclusion']+'\n\n'+audit['minimalFix']+'\n\n'+audit['formalRegression']+'\n\nNo tests/builds/source edits executed. Original Owner [3,4], Replica [1,2], purpose/model, digest/cold assertions retained.\n')
rows=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':rows.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out)))
(out/'SHA256SUMS').write_text('\n'.join(rows)+'\n')
print(json.dumps({'directory':str(out),'files':len(rows)+1,'bytes':sum(f.stat().st_size for f in out.rglob('*') if f.is_file()),'newBoundCount':audit['runs'][0]['eventTypes'].get('DelegationBound'),'oldBoundCount':audit['runs'][1]['eventTypes'].get('DelegationBound')}))

long stroke

import json,pathlib,hashlib,sqlite3,datetime
repo=pathlib.Path('/Users/yuanxi/Workwork/vibe-fs')
root=pathlib.Path('/private/tmp/vibe-fs-oct8-alias-release')
out=root/'r13-first-cause-readonly'
scratch=pathlib.Path('/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/oc-e2e-5z0lRH')
owner='ses_ee50344e2ffelMTDgaoEMqjwb3'
decision='ff5e79c0156cf0ccbe6e21f2f36f8a36065b078f2fcd96565fee810438e6acc8'
journal=scratch/'workspace/.git/wanxiang/events/57ad9ffa277141158b9e3b5995c9f07d.ndjson'
selected=[]
for line,raw in enumerate(journal.read_text().splitlines(),1):
 if owner not in raw and decision not in raw: continue
 event=json.loads(raw)
 if event.get('event_type')=='JournalEnvelope':
  p=event['payload'];fact=p.get('Fact',[])
  if any(t in raw for t in ['BlogObservationCommitted','BloggerRequestMaterialized','ChatExecutionState','RetirementCommitted','PhysicalInputAccepted','PromptAccepted','XTracePartAppended','PromptClaimed','PromptSubmitted','AssessmentCommitted']):
   selected.append({'sourceLine':line,'event':event})
 elif decision in raw:selected.append({'sourceLine':line,'event':event})
(out/'journal-selected-events.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n')
conn=sqlite3.connect((scratch/'xdg/data/opencode/opencode.db').as_uri()+'?mode=ro',uri=True)
conn.row_factory=sqlite3.Row
messages=[dict(r) for r in conn.execute('select id,session_id,time_created,time_updated,data from message where session_id=? order by time_created',(owner,))]
for row in messages: row['data']=json.loads(row['data'])
parts=[dict(r) for r in conn.execute('select id,message_id,session_id,time_created,time_updated,data from part where session_id=? order by time_created',(owner,))]
for row in parts:row['data']=json.loads(row['data'])
errors=[]
for r in conn.execute('select id,aggregate_id,seq,type,data from event where aggregate_id=? order by seq',(owner,)):
 row=dict(r);row['data']=json.loads(row['data'])
 if any(t in json.dumps(row['data']) for t in ['MessageAbortedError','error','compaction']):errors.append(row)
epochs=[dict(r) for r in conn.execute('select * from session_context_epoch where session_id=?',(owner,))]
(out/'owner-physical-host-rows.json').write_text(json.dumps({'owner':owner,'messages':messages,'parts':parts,'errorEvents':errors,'sessionContextEpoch':epochs,'note':'Physical persistent Host rows, not captured transformed provider wire. No account/token table read.'},ensure_ascii=False,indent=2)+'\n')
conn.close()
paths={
 'source-normalTransform':('src/Wanxiangshu/OpenCode/Plugin/PluginTransforms.fs',838,925),
 'compiled-normalTransform-gen343':('dist/OpenCode/Plugin/PluginTransforms.js',838,871),
 'task-builder':('dist/fable_modules/fable-library-js.5.13.0/TaskBuilder.js',1,26),
 'relay-retired-stop':('src/Wanxiangshu/Mission/Relay/OpenCode/NarrativeTransform.fs',128,171),
 'replay-validation-order':('src/Wanxiangshu/Strength/OpenCode/Replay.fs',132,169),
 'lifecycle-required-anchors':('src/Wanxiangshu/Strength/Lifecycle.fs',111,159),
}
source=[]
for label,(relative,start,end) in paths.items():
 p=repo/relative;b=p.read_bytes();lines=b.decode().splitlines()
 entry={'label':label,'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'startLine':start,'endLine':end,'excerpt':'\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines))))}
 source.append(entry)
(out/'source-and-compiled-evidence.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
log=scratch/'xdg/data/opencode/log/opencode.log'
ownerlog=[{'sourceLine':i,'raw':s} for i,s in enumerate(log.read_text().splitlines(),1) if owner in s]
(out/'owner-host-log-lines.json').write_text(json.dumps(ownerlog,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((repo/'.fable-build/build-manifest.json').read_text())
compilerInputs={x['path']:x for x in manifest['compiler']['inputs']}
pluginSource='src/Wanxiangshu/OpenCode/Plugin/PluginTransforms.fs'
sourceMatch=hashlib.sha256((repo/pluginSource).read_bytes()).hexdigest()==compilerInputs[pluginSource]['sha256']
receipt=json.loads((root/'strength-first-cause-e2e.json').read_text())
provenance=[]
for p in [journal,log,root/'strength-first-cause-e2e.log',root/'strength-first-cause-e2e.json',repo/'.fable-build/build-manifest.json']:
 b=p.read_bytes();provenance.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
audit={
 'schema':'r13-first-cause-readonly-audit-v1',
 'owner':owner,'decision':decision,'authorityRoot':'msg_11afcbb300010YFdsPAK6JJgI2','target':'msg_11afcc728001vDCJ00du1TTteb','traceRange':{'startInclusive':3,'endExclusive':6},
 'firstReason':'Promoted Strength target anchor is absent: decision='+decision+' target=msg_11afcc728001vDCJ00du1TTteb',
 'exactFirstFuseTimestamp':'unknown: first trip diagnostic was not retained; later Host stderr tail records preserved reason but no timestamp',
 'exactFirstFuseRawWire':'unknown: original physical rows retain root and target; transformed wire for first trip was not persisted',
 'exactFirstFuseCoverage':'unknown; coverage2 committed at 10:08:56.892Z and coverage8 only at 10:08:57.753Z, after owner cancellation at 10:08:57.340Z',
 'provenCodeDefect':{
  'statement':'normalTransform does not terminate after RetiredAttemptStopped; unit Return is sequenced by Combine into ApplyStrengthReplay and all downstream effects',
  'compiledLine':846,'combineMeaning':'TaskBuilder.Combine(computation1,computation2) => computation1.then(computation2); Return(undefined) resolves normally',
  'relayEffect':'RelayNarrativeTransform.project first awaits actual interruptAttempt then empties outObj.messages and returns RetiredAttemptStopped',
  'strengthConsequence':'normalTransform then calls replay with same original owner ID and emptied messages; Lifecycle requires both owner authority root and promoted target and raises the exact recorded reason',
  'actualRunConnection':'inference supported by old owner retirement/cancel before Blog8 and first reason naming its decision; exact first-trip raw wire/timestamp unrecorded',
 },
 'rejectedInference':'Final Blog coverage10 cannot prove first trip was covered; moving needsRawReplay filter alone has no supporting first-trip coverage evidence and leaves stopped transform downstream effects defect.',
 'formalRegressionSuggested':'Extend real PluginTransformSurface normalTransform capability observation with RetiredAttemptStopped and clear actual outObj; assert effects end at begin/session-time/deferred/relay with no replay, restore, capture, trace commit, Companion, XWire, plan freeze, continuation, delegation, chronicle or sanitize. Keep current/tentative cases and Strength008 missing-anchor negative controls.',
 'minimumFix':'Put normal downstream branch in else or dedicated called function selected only for non-stopped Relay disposition; do not weaken Lifecycle missing-anchor rejection.',
 'build':{'generation':manifest['generation'],'compilerInputDigest':manifest['compiler']['inputDigest'],'pluginSourceMatchesGen343CompilerManifest':sourceMatch},
 'runReceipt':receipt,
 'provenance':provenance,
 'scope':'Read-only audit; no tests, builds, source edits, resource cleanup, or commits executed.'
}
(out/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
lines=['R13 first-cause audit','',audit['provenCodeDefect']['statement'],'',audit['provenCodeDefect']['combineMeaning'],'',audit['provenCodeDefect']['relayEffect'],'',audit['provenCodeDefect']['strengthConsequence'],'',audit['provenCodeDefect']['actualRunConnection'],'','Exact first fuse timestamp / raw wire: unknown.','Coverage: [3,6) Strength traced; coverage2 at 10:08:56.892Z, owner canceled10:08:57.340Z, coverage8 at10:08:57.753Z, final10 at10:08:57.872Z.','Final coverage10 is not first-fuse proof.','',audit['formalRegressionSuggested'],'',audit['minimumFix'],'','No tests/builds/source edits/cleanup run by this audit.']
(out/'audit.txt').write_text('\n'.join(lines)+'\n')
files=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS':files.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}')
(out/'SHA256SUMS').write_text('\n'.join(files)+'\n')
print(json.dumps({'dir':str(out),'files':len(files)+1,'bytes':sum(p.stat().st_size for p in out.iterdir() if p.is_file()),'generation':manifest['generation'],'sourceMatchesManifest':sourceMatch,'selectedJournalEvents':len(selected),'ownerMessages':len(messages),'ownerParts':len(parts)}))

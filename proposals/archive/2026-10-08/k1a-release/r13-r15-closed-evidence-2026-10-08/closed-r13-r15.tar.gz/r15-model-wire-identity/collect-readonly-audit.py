from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

repo = Path('/Users/yuanxi/Workwork/vibe-fs')
out = Path('/private/tmp/vibe-fs-oct8-alias-release/r15-model-wire-identity')
scratch = Path('/private/var/folders/g_/3ydzn7kx5lg9ylq8fd9p_13r0000gn/T/oc-e2e-wnhzKF')
host_repo = Path('/Users/yuanxi/Workwork/opencode')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def exclusive_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def capture_excerpt(path, start, end):
    lines = path.read_text().splitlines()
    return {'path': str(path), 'sha256': digest(path), 'startLine': start,
            'endLine': end, 'text': '\n'.join(lines[start - 1:end])}

selected = []
db = scratch / 'xdg/data/opencode/opencode.db'
conn = sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True)
for session_id in ['ses_ee4ecc0e6ffe1BFNvPHm42Frnb', 'ses_ee4ecb8aeffeFjgXrbghYaigZ6',
                   'ses_ee4ec93f6ffeNw7HZcH0e74TU1', 'ses_ee4ec9280ffeO4bksWczeGUH56']:
    session = conn.execute('select id,parent_id,model,time_created,time_updated from session where id=?',
                           (session_id,)).fetchone()
    item = {'session': dict(zip(['id', 'parentId', 'initialModel', 'created', 'updated'], session)),
            'assistantMessages': []}
    for message_id, created, raw in conn.execute(
            'select id,time_created,data from message where session_id=? order by time_created,id',
            (session_id,)):
        body = json.loads(raw)
        if body.get('role') != 'assistant':
            continue
        item['assistantMessages'].append({'id': message_id, 'created': created,
            **{key: body.get(key) for key in ['role', 'parentID', 'providerID', 'modelID',
                                             'agent', 'finish', 'time', 'error']}})
    selected.append(item)
conn.close()
exclusive_json(out / 'actual-host-model-observations.json', {
    'source': str(db), 'readOnlyMode': True,
    'scope': 'Four known Strength owner/replica sessions; assistant identity, model and terminal fields only.',
    'limit': 'Host DB evidence is an investigation receipt, not previously unrecorded HTTP headers. Session initialModel is not the actual routed assistant model.',
    'sessions': selected})

route_path = scratch / 'home/.config/opencode/wanxiangshu-routing-decisions.jsonl'
route_lines = [json.loads(line) for line in route_path.read_text().splitlines() if line]
exclusive_json(out / 'actual-routing-observations.json', {
    'source': str(route_path), 'sha256': digest(route_path),
    'limit': 'Routing observations have role/purpose/model but no session affinity; cannot identify a particular HTTP request alone.',
    'observations': [{key: row.get(key) for key in ['role', 'purpose', 'model']} for row in route_lines]})

excerpts = [
    capture_excerpt(repo / 'requirements/verification-system/tests/e2e/support/isolated-env.js', 33, 113),
    capture_excerpt(repo / 'requirements/verification-system/tests/e2e/support/strict-mock-provider.js', 35, 58),
    capture_excerpt(repo / 'requirements/verification-system/tests/e2e/support/strict-mock-provider.js', 339, 345),
    capture_excerpt(repo / 'requirements/verification-system/tests/e2e/support/long-stroke-oracles.mjs', 1152, 1168),
    capture_excerpt(repo / 'requirements/verification-system/tests/e2e/support/long-stroke-oracles.mjs', 1239, 1292),
    capture_excerpt(repo / 'requirements/speculative-investigation/WHAT.md', 173, 177),
    capture_excerpt(host_repo / 'packages/opencode/src/provider/provider.ts', 1495, 1506),
    capture_excerpt(host_repo / 'packages/opencode/src/session/llm/request.ts', 184, 205),
]
exclusive_json(out / 'source-excerpts.json', {'hostSourceCommit': subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=host_repo, text=True).strip(),
    'hostSourceLimit': 'Local checkout documents public model.headers propagation; installed Host binary source equivalence has not been established by this audit.',
    'excerpts': excerpts})

root = out.parent
for name in ['r14-event-observer-e2e.log', 'r14-event-observer-e2e.json']:
    target = out / name
    with (root / name).open('rb') as source, target.open('xb') as dest:
        shutil.copyfileobj(source, dest)

raw_receipt = json.loads((root / 'r14-event-observer-e2e.json').read_text())
exclusive_json(out / 'audit.json', {
    'problem': 'Qualified model target compared to raw OpenAI wire model; mock did not record transport provider identity.',
    'actualRun': {'receipt': 'r14-event-observer-e2e.json', 'preliminaryDirtyInput': True,
        'commit': raw_receipt['before']['commit'], 'inputDigest': raw_receipt['before']['digest'],
        'buildGeneration': raw_receipt['before']['build']['generation'],
        'inputsEqual': raw_receipt['inputsEqual'], 'durationMs': raw_receipt['durationMs'],
        'exitCode': raw_receipt['exitCode'], 'monitorPid': raw_receipt['monitorPid'],
        'monitorObservation': raw_receipt['monitorObservation'],
        'tap': {'tests': 15, 'pass': 14, 'fail': 1, 'skip': 0, 'TODO': 0, 'durationMs': 17235.059208},
        'actualFailure': 'DELEGATE 9.2 replica must run exactly on configured Predictor target; actual test-model-b versus expected test/test-model-b'},
    'cause': [
        'The OpenAI-compatible body carries the bare model ID.',
        'All three isolated providers share one baseURL and the same fixture API key; endpoint alone cannot prove provider identity.',
        'test-model is available from test, opencode and backup, so assigning every bare ID to test would corrupt fallback/capacity evidence.',
        'Mock requestRecordOf currently observes session IDs but no provider identity. requestModel returns only the raw model string.',
    ],
    'minimalFix': [
        'Each configured provider model declares x-wxs-e2e-provider-id through the existing public model.headers surface.',
        'The actual HTTP recorder takes providerID only from that transport header, overrides body spoof, and keeps metadata non-enumerable.',
        'Existing requestModel requires observed provider identity and a non-empty actual model, then returns provider/model; qualified target stays exact.',
    ],
    'formalDraft': {'redPatch': 'regression-red.patch', 'greenPatch': 'fixture-green.patch',
        'boundary': 'Real compiled ScenarioRuntime, actual StrictMockProvider HTTP, production readonly instruction and real Strength Surface/LocalStore two-Decision Bound.',
        'negativeControls': ['Same bare model on wrong provider', 'Missing transport provider', 'Body provider spoof cannot replace header'],
        'status': 'Drafts only: this child did not apply patches or execute tests/builds.'},
    'remaining': [
        'Parent must run formal red before fixture fix, then related green and a new real Host E2E.',
        'Historical HTTP request arrays/headers were not persisted and are unknown; do not invent them from route/DB evidence.',
        'Recovery Owner in actual wnhzKF routes opencode while its Replica routes test. Existing all-owner capacity comparison is separately under investigation; this model fix does not close it.',
        'Session-wide assistant counts include later review/suicide work. Decision/root/sourcecall scope is a separate oracle concern, not permission to increase expected counts.',
        'This receipt is a dirty-input local investigation, not final release or exact final CI acceptance.',
    ]})

entries = []
for path in sorted(out.iterdir()):
    if path.is_file() and path.name not in ['inventory.json', 'SHA256SUMS']:
        entries.append({'file': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
exclusive_json(out / 'inventory.json', {'files': len(entries),
    'bytes': sum(item['bytes'] for item in entries), 'entries': entries})
with (out / 'SHA256SUMS').open('x') as stream:
    for item in entries:
        stream.write(item['sha256'] + '  ' + item['file'] + '\n')
print(json.dumps({'directory': str(out), 'files': len(entries), 'bytes': sum(item['bytes'] for item in entries)}))
